(function(){var T=Object.defineProperty;var S=(n,t,e)=>t in n?T(n,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):n[t]=e;var d=(n,t,e)=>S(n,typeof t!="symbol"?t+"":t,e);class L{constructor(t){d(this,"observer",null);d(this,"debounceTimer",null);d(this,"onIssueDetected");this.onIssueDetected=t}start(){this.observer=new MutationObserver(()=>this.handleMutations()),this.observer.observe(document.body,{childList:!0,subtree:!0,attributes:!0}),this.runHeuristics()}stop(){this.observer&&this.observer.disconnect(),this.debounceTimer&&window.clearTimeout(this.debounceTimer)}handleMutations(){this.debounceTimer&&window.clearTimeout(this.debounceTimer),this.debounceTimer=window.setTimeout(()=>{this.runHeuristics()},2e3)}runHeuristics(){const t=[];document.querySelectorAll("img:not([alt])").forEach(e=>{t.push({type:"accessibility",severity:"high",title:"Missing Alternative Text",description:"Images should have descriptive alt text for screen readers.",selector:this.getSelector(e)})}),document.querySelectorAll("button, a").forEach(e=>{const i=e.getBoundingClientRect();i.width>0&&i.height>0&&(i.width<44||i.height<44)&&t.push({type:"ux",severity:"medium",title:"Small Touch Target",description:"Element is smaller than 44x44px, which may be difficult for mobile users.",selector:this.getSelector(e)})}),document.querySelectorAll('input:not([type="hidden"]):not([aria-label]):not([aria-labelledby])').forEach(e=>{const i=e.id;(i?document.querySelector(`label[for="${i}"]`):e.closest("label"))||t.push({type:"accessibility",severity:"high",title:"Missing Form Label",description:"Input elements should have associated labels for accessibility.",selector:this.getSelector(e)})}),t.length>0&&this.onIssueDetected(t)}getSelector(t){const e=[];let i=t;for(;i&&i.nodeType===Node.ELEMENT_NODE;){let o=i.nodeName.toLowerCase();if(i.id){o+="#"+i.id,e.unshift(o);break}else{let r=i,s=1;for(;r.previousElementSibling;)r=r.previousElementSibling,r.nodeName.toLowerCase()===o&&s++;s!==1&&(o+=`:nth-of-type(${s})`)}e.unshift(o),i=i.parentElement}return e.join(" > ")}}function M(){const n=[],t=document.querySelectorAll("img");let e=0;return t.forEach(i=>{var o;(!i.hasAttribute("alt")||((o=i.getAttribute("alt"))==null?void 0:o.trim())==="")&&e++}),e>0&&n.push({type:"accessibility",severity:"high",title:"Missing Alt Text",description:`${e} image(s) missing alt text for screen readers`,count:e}),n}function $(){const n=[],t=document.querySelectorAll("p, span, a, button, h1, h2, h3, h4, h5, h6");let e=0;return t.forEach(i=>{const o=window.getComputedStyle(i),r=o.color,s=o.backgroundColor,a=r.match(/\d+/g),c=s.match(/\d+/g);if(a&&c){const[l,p,u]=a.map(Number),[h,m,g]=c.map(Number),y=.299*l+.587*p+.114*u,b=.299*h+.587*m+.114*g;Math.abs(y-b)<50&&e++}}),e>0&&n.push({type:"accessibility",severity:"medium",title:"Low Color Contrast",description:`${e} element(s) may have insufficient color contrast`,count:e}),n}function _(){const n=[],t=document.querySelectorAll('input:not([type="hidden"]), textarea, select');let e=0;return t.forEach(i=>{const o=i.getAttribute("id"),r=i.getAttribute("aria-label"),s=i.getAttribute("aria-labelledby");!(o&&document.querySelector(`label[for="${o}"]`))&&!r&&!s&&e++}),e>0&&n.push({type:"accessibility",severity:"high",title:"Missing Form Labels",description:`${e} form field(s) missing accessible labels`,count:e}),n}function D(){const n=[],t=document.querySelectorAll('[class*="error"], [class*="Error"]');return t.length>0&&n.push({type:"console",severity:"medium",title:"Potential Errors Detected",description:`${t.length} element(s) with error-related classes found`,count:t.length}),n}function N(){const n=[],t=document.querySelectorAll("a[href]");let e=0;return t.forEach(i=>{const o=i.getAttribute("href");(!o||o==="#"||o==="javascript:void(0)"||o==="")&&e++}),e>0&&n.push({type:"accessibility",severity:"low",title:"Empty or Placeholder Links",description:`${e} link(s) with no destination or placeholder href`,count:e}),n}function z(){const n=[],t=document.title;return(!t||t.trim()==="")&&n.push({type:"seo",severity:"high",title:"Missing Page Title",description:"Page is missing a title tag, important for SEO and accessibility"}),n}function P(){var e;const n=[],t=document.querySelector('meta[name="description"]');return(!t||!((e=t.getAttribute("content"))!=null&&e.trim()))&&n.push({type:"seo",severity:"medium",title:"Missing Meta Description",description:"Page is missing a meta description tag, important for SEO"}),n}function B(){const n=[];if(Array.from(document.querySelectorAll("h1, h2, h3, h4, h5, h6")).length===0)return n;const e=document.querySelectorAll("h1").length;return e>1&&n.push({type:"accessibility",severity:"medium",title:"Multiple H1 Tags",description:`Page has ${e} H1 tags. Should have only one main heading.`,count:e}),e===0&&n.push({type:"accessibility",severity:"high",title:"Missing H1 Tag",description:"Page is missing a main H1 heading"}),n}function O(){const n=[];try{n.push(...M()),n.push(...$()),n.push(..._()),n.push(...D()),n.push(...N()),n.push(...z()),n.push(...P()),n.push(...B())}catch(t){console.error("Error running proactive checks:",t)}return n}function v(n){return{critical:n.filter(t=>t.severity==="critical").length,high:n.filter(t=>t.severity==="high").length,medium:n.filter(t=>t.severity==="medium").length,low:n.filter(t=>t.severity==="low").length,total:n.length}}class F{constructor(){d(this,"state",{isListening:!1,isProcessing:!1,cursorPosition:null,lastCommand:null,confidence:0});d(this,"overlayElement",null);d(this,"cursorMarker",null);d(this,"voiceIndicator",null);d(this,"feedbackBox",null);this.init(),this.setupEventListeners()}init(){this.overlayElement=document.createElement("div"),this.overlayElement.id="wand-overlay",this.overlayElement.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 2147483647;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    `,this.cursorMarker=document.createElement("div"),this.cursorMarker.id="wand-cursor-marker",this.cursorMarker.style.cssText=`
      position: absolute;
      width: 40px;
      height: 40px;
      border: 3px solid #3b82f6;
      border-radius: 50%;
      background: rgba(59, 130, 246, 0.2);
      transform: translate(-50%, -50%);
      display: none;
      pointer-events: none;
      animation: wand-pulse 1.5s ease-in-out infinite;
    `,this.voiceIndicator=document.createElement("div"),this.voiceIndicator.id="wand-voice-indicator",this.voiceIndicator.style.cssText=`
      position: fixed;
      bottom: 30px;
      right: 30px;
      width: 60px;
      height: 60px;
      background: linear-gradient(135deg, #3b82f6, #8b5cf6);
      border-radius: 50%;
      display: none;
      pointer-events: auto;
      cursor: pointer;
      box-shadow: 0 4px 20px rgba(59, 130, 246, 0.4);
      transition: all 0.3s ease;
    `,this.voiceIndicator.innerHTML=`
      <svg width="60" height="60" viewBox="0 0 60 60" style="padding: 15px;">
        <path d="M30 10 C25 10 22 13 22 18 L22 30 C22 35 25 38 30 38 C35 38 38 35 38 30 L38 18 C38 13 35 10 30 10 Z M18 28 L18 30 C18 37 23 43 30 43 C37 43 42 37 42 30 L42 28 M30 43 L30 50 M24 50 L36 50" 
              stroke="white" stroke-width="2" fill="none" stroke-linecap="round"/>
      </svg>
    `,this.feedbackBox=document.createElement("div"),this.feedbackBox.id="wand-feedback",this.feedbackBox.style.cssText=`
      position: fixed;
      top: 30px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(15, 23, 42, 0.95);
      color: white;
      padding: 16px 24px;
      border-radius: 12px;
      display: none;
      pointer-events: none;
      max-width: 500px;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(10px);
    `;const t=document.createElement("style");t.textContent=`
      @keyframes wand-pulse {
        0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
        50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.7; }
      }
      
      @keyframes wand-listening {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.1); }
      }
      
      #wand-voice-indicator.listening {
        animation: wand-listening 1s ease-in-out infinite;
      }
      
      #wand-voice-indicator:hover {
        transform: scale(1.1);
      }
    `,document.head.appendChild(t),this.overlayElement.appendChild(this.cursorMarker),this.overlayElement.appendChild(this.voiceIndicator),this.overlayElement.appendChild(this.feedbackBox),document.body.appendChild(this.overlayElement)}setupEventListeners(){var t;document.addEventListener("mousemove",e=>{this.state.cursorPosition={x:e.clientX,y:e.clientY},this.state.isListening&&this.cursorMarker&&(this.cursorMarker.style.left=`${e.clientX}px`,this.cursorMarker.style.top=`${e.clientY}px`)}),(t=this.voiceIndicator)==null||t.addEventListener("click",()=>{this.toggleListening()}),document.addEventListener("keydown",e=>{(e.ctrlKey||e.metaKey)&&e.code==="Space"&&(e.preventDefault(),this.toggleListening())}),chrome.runtime.onMessage.addListener(e=>{e.type==="WAND_COMMAND"?this.handleCommand(e.command):e.type==="WAND_RESPONSE"?this.handleResponse(e.response):e.type==="WAND_ERROR"&&this.showError(e.error)})}toggleListening(){this.state.isListening=!this.state.isListening,this.state.isListening?this.startListening():this.stopListening()}startListening(){console.log("🎤 Wand: Started listening"),this.voiceIndicator&&(this.voiceIndicator.style.display="block",this.voiceIndicator.classList.add("listening")),this.cursorMarker&&this.state.cursorPosition&&(this.cursorMarker.style.display="block",this.cursorMarker.style.left=`${this.state.cursorPosition.x}px`,this.cursorMarker.style.top=`${this.state.cursorPosition.y}px`),this.showFeedback("Listening... Speak your command","info"),this.startVoiceRecognition()}stopListening(){console.log("🎤 Wand: Stopped listening"),this.voiceIndicator&&this.voiceIndicator.classList.remove("listening"),this.cursorMarker&&(this.cursorMarker.style.display="none"),this.stopVoiceRecognition()}startVoiceRecognition(){if(!("webkitSpeechRecognition"in window)){this.showError("Voice recognition not supported in this browser");return}const t=new window.webkitSpeechRecognition;t.continuous=!1,t.interimResults=!0,t.lang="en-US",t.onresult=e=>{const i=e.results[0][0].transcript;e.results[0].isFinal?this.handleCommand(i):this.showFeedback(`Hearing: "${i}"`,"info")},t.onerror=e=>{console.error("Voice recognition error:",e.error),this.showError(`Voice error: ${e.error}`),this.stopListening()},t.onend=()=>{this.state.isListening&&t.start()},t.start(),this.recognition=t}stopVoiceRecognition(){this.recognition&&(this.recognition.stop(),this.recognition=null)}async handleCommand(t){console.log("🪄 Wand command:",t),this.state.lastCommand=t,this.state.isProcessing=!0,this.showFeedback(`Processing: "${t}"`,"processing");const e=window.__AUDIT_WAND__,i=e==null?void 0:e.isAuditMode,o={url:window.location.href,title:document.title,dom:this.getSimplifiedDOM(),viewport:{width:window.innerWidth,height:window.innerHeight}};let r=null,s=null;if(this.state.cursorPosition&&(s=document.elementFromPoint(this.state.cursorPosition.x,this.state.cursorPosition.y),s&&(r=this.getElementDescription(s))),i&&this.isAuditCommand(t)){this.handleAuditModeCommand(t,s);return}chrome.runtime.sendMessage({type:"WAND_PROCESS_COMMAND",data:{voiceCommand:t,cursorPosition:this.state.cursorPosition?{...this.state.cursorPosition,elementUnderCursor:r}:void 0,pageContext:o}})}isAuditCommand(t){const e=["inspect","analyze","check","fix","improve","suggest","explain","compare","contrast","accessibility","performance","semantic","typography","color","layout","navigation","user flow","touch target","keyboard","screen reader"],i=t.toLowerCase();return e.some(o=>i.includes(o))}handleAuditModeCommand(t,e){var s;const i=window.__AUDIT_WAND__;if(!i)return;let o="analyze";t.includes("inspect")||t.includes("check")?o="inspect":t.includes("fix")||t.includes("improve")?o="fix":t.includes("explain")||t.includes("why")?o="explain":t.includes("compare")?o="compare":t.includes("suggest")&&(o="suggest");let r;if(e){const a=e.getBoundingClientRect();r={element:e,selector:this.getElementSelector(e),position:{x:a.left+a.width/2,y:a.top+a.height/2}}}chrome.runtime.sendMessage({type:"WAND_AUDIT_COMMAND",command:{type:o,target:r,context:t,agentType:i.currentAgent}}),this.showFeedback(`Analyzing with ${(s=i.currentAgent)==null?void 0:s.toUpperCase()} Agent...`,"processing")}getElementSelector(t){if(t.id)return`#${t.id}`;const e=[];let i=t;for(;i&&i!==document.body;){let o=i.tagName.toLowerCase();i.className&&(o+=`.${i.className.toString().split(" ").join(".")}`),e.unshift(o),i=i.parentElement}return e.join(" > ")}handleResponse(t){console.log("✅ Wand response:",t),this.state.isProcessing=!1,this.state.confidence=t.confidence,this.showFeedback(t.understanding,"success"),this.speak(t.speech),t.needsConfirmation?this.requestConfirmation(t):this.executeActions(t.actions),setTimeout(()=>{this.stopListening()},2e3)}async executeActions(t){for(const e of t){switch(console.log("🎯 Executing action:",e.type),e.type){case"click":await this.executeClick(e);break;case"scroll":await this.executeScroll(e);break;case"navigate":await this.executeNavigate(e);break;case"type":await this.executeType(e);break;case"wait":await this.executeWait(e);break}await new Promise(i=>setTimeout(i,300))}}async executeClick(t){var e,i,o;if((e=t.target)!=null&&e.x&&((i=t.target)!=null&&i.y)){const r=document.elementFromPoint(t.target.x,t.target.y);r instanceof HTMLElement&&(r.click(),this.showClickAnimation(t.target.x,t.target.y))}else if((o=t.target)!=null&&o.selector){const r=document.querySelector(t.target.selector);if(r instanceof HTMLElement){r.click();const s=r.getBoundingClientRect();this.showClickAnimation(s.left+s.width/2,s.top+s.height/2)}}}async executeScroll(t){var i,o;const e=t.value||300;if((i=t.target)!=null&&i.x&&((o=t.target)!=null&&o.y)){const r=document.elementFromPoint(t.target.x,t.target.y);r&&r.scrollBy({top:e,behavior:"smooth"})}else window.scrollBy({top:e,behavior:"smooth"})}async executeNavigate(t){var e;(e=t.target)!=null&&e.url&&(window.location.href=t.target.url)}async executeType(t){var e;if((e=t.target)!=null&&e.selector&&t.value){const i=document.querySelector(t.target.selector);(i instanceof HTMLInputElement||i instanceof HTMLTextAreaElement)&&(i.value=t.value,i.dispatchEvent(new Event("input",{bubbles:!0})))}}async executeWait(t){const e=t.value||1e3;await new Promise(i=>setTimeout(i,e))}requestConfirmation(t){confirm(`${t.understanding}

Actions:
${t.actions.map(i=>`- ${i.description}`).join(`
`)}

Proceed?`)?this.executeActions(t.actions):this.showFeedback("Action cancelled","info")}showFeedback(t,e){if(!this.feedbackBox)return;const i={info:"#3b82f6",success:"#10b981",error:"#ef4444",processing:"#8b5cf6"};this.feedbackBox.style.display="block",this.feedbackBox.style.borderLeft=`4px solid ${i[e]}`,this.feedbackBox.textContent=t,setTimeout(()=>{this.feedbackBox&&(this.feedbackBox.style.display="none")},3e3)}showError(t){this.showFeedback(`Error: ${t}`,"error"),this.speak(`Sorry, there was an error: ${t}`)}speak(t){if("speechSynthesis"in window){const e=new SpeechSynthesisUtterance(t);e.rate=1.1,e.pitch=1,window.speechSynthesis.speak(e)}}showClickAnimation(t,e){const i=document.createElement("div");i.style.cssText=`
      position: fixed;
      left: ${t}px;
      top: ${e}px;
      width: 20px;
      height: 20px;
      border: 2px solid #3b82f6;
      border-radius: 50%;
      transform: translate(-50%, -50%);
      pointer-events: none;
      z-index: 2147483647;
      animation: wand-ripple 0.6s ease-out;
    `;const o=document.createElement("style");o.textContent=`
      @keyframes wand-ripple {
        0% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
        100% { transform: translate(-50%, -50%) scale(3); opacity: 0; }
      }
    `,document.head.appendChild(o),document.body.appendChild(i),setTimeout(()=>i.remove(),600)}getSimplifiedDOM(){const t=[];return document.querySelectorAll("button, a, input, video, [role='button']").forEach(e=>{var a;const i=e.tagName.toLowerCase(),o=((a=e.textContent)==null?void 0:a.trim().substring(0,50))||"",r=e.id?`#${e.id}`:"",s=e.className?`.${e.className.split(" ").join(".")}`:"";t.push(`<${i}${r}${s}>${o}</${i}>`)}),t.slice(0,50).join(`
`)}getElementDescription(t){var s;const e=t.tagName.toLowerCase(),i=((s=t.textContent)==null?void 0:s.trim().substring(0,100))||"",o=t.id?`#${t.id}`:"",r=t.className?`.${t.className.toString().split(" ").join(".")}`:"";return`${e}${o}${r}: "${i}"`}show(){this.voiceIndicator&&(this.voiceIndicator.style.display="block")}hide(){this.overlayElement&&(this.overlayElement.style.display="none")}toggle(){return this.toggleListening(),this.state.isListening}isActive(){return this.state.isListening}}const E=new F;E.show();window.__WAND_OVERLAY__=E;class U{constructor(){d(this,"isAuditMode",!1);d(this,"currentAgent",null);d(this,"highlightedElements",new Map);this.setupAuditCommands()}enableAuditMode(t){this.isAuditMode=!0,this.currentAgent=t,console.log(`🎨 ${t.toUpperCase()} Audit Mode enabled with Wand`),this.showAuditModeIndicator(t),this.enableAuditVoiceCommands()}disableAuditMode(){this.isAuditMode=!1,this.currentAgent=null,this.clearAllHighlights(),this.hideAuditModeIndicator()}setupAuditCommands(){chrome.runtime.onMessage.addListener(t=>{t.type==="WAND_AUDIT_COMMAND"&&this.isAuditMode&&this.handleAuditCommand(t.command)})}enableAuditVoiceCommands(){const t={ui:["inspect this element","check colors here","analyze typography","check contrast","what's wrong with this?","suggest improvements","compare with best practices"],ux:["check accessibility","test navigation","analyze user flow","check touch targets","test keyboard navigation","check screen reader","suggest UX improvements"],dom:["inspect structure","check performance","analyze hierarchy","check semantics","find unused elements","optimize this","check best practices"]};console.log(`📋 Available commands for ${this.currentAgent}:`,t[this.currentAgent])}async handleAuditCommand(t){console.log(`🎤 Audit command: ${t.context}`);try{let e=null;t.target&&(e=t.target.element);let i;switch(t.type){case"inspect":i=await this.inspectElement(e,t.context);break;case"analyze":i=await this.analyzeElement(e,t.context);break;case"fix":i=await this.suggestFix(e,t.context);break;case"explain":i=await this.explainIssue(e,t.context);break;case"compare":i=await this.compareWithBestPractices(e,t.context);break;case"suggest":i=await this.suggestImprovements(e,t.context);break;default:i=await this.analyzeElement(e,t.context)}this.displayAuditResponse(i,e),i.visualAnnotations&&this.applyVisualAnnotations(i.visualAnnotations)}catch(e){console.error("❌ Audit command error:",e),this.showError("Failed to process audit command")}}async inspectElement(t,e){if(!t)return{analysis:"No element selected. Please point at an element.",issues:[],speech:"Please point at an element to inspect."};const i=this.getElementInfo(t);return await this.callAuditAgent({command:"inspect",element:i,context:e,agentType:this.currentAgent})}async analyzeElement(t,e){if(!t)return await this.analyzeFullPage(e);const i=this.getElementInfo(t);return await this.callAuditAgent({command:"analyze",element:i,context:e,agentType:this.currentAgent})}async suggestFix(t,e){if(!t)return{analysis:"No element selected for fix suggestions.",issues:[],speech:"Please point at an element to get fix suggestions."};const i=this.getElementInfo(t);return await this.callAuditAgent({command:"fix",element:i,context:e,agentType:this.currentAgent})}async explainIssue(t,e){const i=t?this.getElementInfo(t):null;return await this.callAuditAgent({command:"explain",element:i,context:e,agentType:this.currentAgent})}async compareWithBestPractices(t,e){const i=t?this.getElementInfo(t):null;return await this.callAuditAgent({command:"compare",element:i,context:e,agentType:this.currentAgent})}async suggestImprovements(t,e){const i=t?this.getElementInfo(t):null;return await this.callAuditAgent({command:"suggest",element:i,context:e,agentType:this.currentAgent})}async analyzeFullPage(t){return await this.callAuditAgent({command:"analyze",element:null,context:t,agentType:this.currentAgent})}async callAuditAgent(t){const e=await fetch(`http://127.0.0.1:5001/w3bn3xt/us-central1/audit${t.agentType.toUpperCase()}Wand`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(t)});if(!e.ok)throw new Error(`Agent API error: ${e.statusText}`);return await e.json()}getElementInfo(t){var o;const e=t.getBoundingClientRect(),i=window.getComputedStyle(t);return{tagName:t.tagName.toLowerCase(),id:t.id,className:t.className,textContent:(o=t.textContent)==null?void 0:o.trim().substring(0,200),attributes:Array.from(t.attributes).map(r=>({name:r.name,value:r.value})),position:{x:e.left,y:e.top,width:e.width,height:e.height},styles:{color:i.color,backgroundColor:i.backgroundColor,fontSize:i.fontSize,fontFamily:i.fontFamily,display:i.display,position:i.position,zIndex:i.zIndex},accessibility:{role:t.getAttribute("role"),ariaLabel:t.getAttribute("aria-label"),ariaDescribedBy:t.getAttribute("aria-describedby"),tabIndex:t.getAttribute("tabindex")}}}displayAuditResponse(t,e){var c;const i=document.createElement("div");i.id="audit-wand-response",i.style.cssText=`
      position: fixed;
      top: 80px;
      right: 30px;
      width: 400px;
      max-height: 600px;
      background: rgba(15, 23, 42, 0.98);
      color: white;
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
      z-index: 2147483646;
      overflow-y: auto;
      backdrop-filter: blur(20px);
      border: 1px solid rgba(59, 130, 246, 0.3);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    `;const o=document.createElement("div");o.style.cssText=`
      display: inline-block;
      padding: 4px 12px;
      background: linear-gradient(135deg, #3b82f6, #8b5cf6);
      border-radius: 20px;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 16px;
    `,o.textContent=`${this.currentAgent} Agent`;const r=document.createElement("div");r.style.cssText=`
      font-size: 14px;
      line-height: 1.6;
      margin-bottom: 20px;
      color: rgba(255, 255, 255, 0.9);
    `,r.textContent=t.analysis;const s=document.createElement("div");if(t.issues.length>0){const l=document.createElement("div");l.style.cssText=`
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        color: rgba(255, 255, 255, 0.6);
        margin-bottom: 12px;
        letter-spacing: 0.5px;
      `,l.textContent="Issues Found",s.appendChild(l),t.issues.forEach(p=>{const u=document.createElement("div");u.style.cssText=`
          background: rgba(255, 255, 255, 0.05);
          border-left: 3px solid ${this.getIssueColor(p.severity)};
          padding: 12px;
          border-radius: 8px;
          margin-bottom: 10px;
        `;const h=document.createElement("div");h.style.cssText=`
          font-size: 10px;
          font-weight: 700;
          text-transform: uppercase;
          color: ${this.getIssueColor(p.severity)};
          margin-bottom: 6px;
        `,h.textContent=p.severity;const m=document.createElement("div");m.style.cssText=`
          font-size: 13px;
          margin-bottom: 8px;
          color: rgba(255, 255, 255, 0.9);
        `,m.textContent=p.description;const g=document.createElement("div");g.style.cssText=`
          font-size: 12px;
          color: rgba(255, 255, 255, 0.7);
          font-style: italic;
        `,g.textContent=`💡 ${p.suggestion}`,u.appendChild(h),u.appendChild(m),u.appendChild(g),s.appendChild(u)})}const a=document.createElement("button");a.textContent="×",a.style.cssText=`
      position: absolute;
      top: 16px;
      right: 16px;
      background: none;
      border: none;
      color: white;
      font-size: 24px;
      cursor: pointer;
      opacity: 0.6;
      transition: opacity 0.2s;
    `,a.onmouseover=()=>a.style.opacity="1",a.onmouseout=()=>a.style.opacity="0.6",a.onclick=()=>i.remove(),i.appendChild(a),i.appendChild(o),i.appendChild(r),i.appendChild(s),(c=document.getElementById("audit-wand-response"))==null||c.remove(),document.body.appendChild(i),this.speak(t.speech),e&&this.highlightElement(e,"audit")}applyVisualAnnotations(t){t.forEach(e=>{const i=document.querySelector(e.element);if(i)switch(e.type){case"highlight":this.highlightElement(i,e.color);break;case"arrow":this.drawArrow(i,e.message);break;case"label":this.addLabel(i,e.message);break}})}highlightElement(t,e="audit"){const i={audit:"rgba(59, 130, 246, 0.3)",critical:"rgba(239, 68, 68, 0.3)",warning:"rgba(245, 158, 11, 0.3)",info:"rgba(16, 185, 129, 0.3)"},o=document.createElement("div"),r=t.getBoundingClientRect();if(o.style.cssText=`
      position: fixed;
      left: ${r.left}px;
      top: ${r.top}px;
      width: ${r.width}px;
      height: ${r.height}px;
      background: ${i[e]||i.audit};
      border: 2px solid ${e==="audit"?"#3b82f6":"#ef4444"};
      pointer-events: none;
      z-index: 2147483645;
      border-radius: 4px;
      animation: audit-highlight-pulse 2s ease-in-out infinite;
    `,!document.getElementById("audit-highlight-styles")){const s=document.createElement("style");s.id="audit-highlight-styles",s.textContent=`
        @keyframes audit-highlight-pulse {
          0%, 100% { opacity: 0.6; }
          50% { opacity: 1; }
        }
      `,document.head.appendChild(s)}document.body.appendChild(o),this.highlightedElements.set(t,o),setTimeout(()=>{o.remove(),this.highlightedElements.delete(t)},5e3)}drawArrow(t,e){console.log("Drawing arrow to:",t,e)}addLabel(t,e){const i=t.getBoundingClientRect(),o=document.createElement("div");o.style.cssText=`
      position: fixed;
      left: ${i.left}px;
      top: ${i.top-30}px;
      background: rgba(59, 130, 246, 0.95);
      color: white;
      padding: 4px 12px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
      pointer-events: none;
      z-index: 2147483646;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    `,o.textContent=e,document.body.appendChild(o),setTimeout(()=>o.remove(),5e3)}clearAllHighlights(){this.highlightedElements.forEach(t=>t.remove()),this.highlightedElements.clear()}showAuditModeIndicator(t){const e=document.createElement("div");e.id="audit-mode-indicator",e.style.cssText=`
      position: fixed;
      top: 30px;
      left: 30px;
      background: linear-gradient(135deg, #3b82f6, #8b5cf6);
      color: white;
      padding: 12px 20px;
      border-radius: 12px;
      font-size: 14px;
      font-weight: 700;
      z-index: 2147483647;
      box-shadow: 0 10px 30px rgba(59, 130, 246, 0.4);
      display: flex;
      align-items: center;
      gap: 10px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    `;const i=document.createElement("span");i.textContent=t==="ui"?"🎨":t==="ux"?"🧠":"🏗️",i.style.fontSize="20px";const o=document.createElement("span");o.textContent=`${t.toUpperCase()} Audit Mode`;const r=document.createElement("span");r.style.cssText=`
      width: 8px;
      height: 8px;
      background: #22c55e;
      border-radius: 50%;
      animation: audit-pulse 1.5s ease-in-out infinite;
    `,e.appendChild(i),e.appendChild(o),e.appendChild(r),document.body.appendChild(e)}hideAuditModeIndicator(){var t;(t=document.getElementById("audit-mode-indicator"))==null||t.remove()}getIssueColor(t){const e={critical:"#ef4444",warning:"#f59e0b",info:"#10b981"};return e[t]||e.info}speak(t){if("speechSynthesis"in window){const e=new SpeechSynthesisUtterance(t);e.rate=1.1,e.pitch=1,window.speechSynthesis.speak(e)}}showError(t){console.error("❌ Audit Wand error:",t),this.speak(`Error: ${t}`)}}const q=new U;window.__AUDIT_WAND__=q;console.log("Audibit Content Script Active");window.__AUDIBIT_LOADED__=!0;let f=[];function w(){f=O();const n=v(f);console.log("Audibit proactive checks complete:",n),f.length>0&&(C(f),chrome.runtime.sendMessage({type:"LOCAL_ISSUES_FOUND",issues:f,summary:n}))}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",w):w();const W=new L(()=>{console.log("Audibit detected DOM changes, re-running checks"),w()});async function C(n){let t=document.getElementById("audibit-overlay-container");if(!t){t=document.createElement("div"),t.id="audibit-overlay-container",document.body.appendChild(t);const e=t.attachShadow({mode:"open"}),i=document.createElement("div");i.id="audibit-root";const o=document.createElement("style");o.textContent=`
      #audibit-root {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 16px 20px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        z-index: 999999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        cursor: pointer;
        transition: transform 0.2s;
      }
      #audibit-root:hover {
        transform: translateY(-2px);
      }
      .audibit-badge {
        display: flex;
        align-items: center;
        gap: 12px;
      }
      .audibit-icon {
        font-size: 24px;
      }
      .audibit-content {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .audibit-title {
        font-weight: 600;
        font-size: 14px;
      }
      .audibit-count {
        font-size: 12px;
        opacity: 0.9;
      }
      @keyframes audibit-shimmer {
        0% { background-position: 200% 0; }
        100% { background-position: -200% 0; }
      }
    `,e.appendChild(o),e.appendChild(i);const r=v(n);i.innerHTML=`
      <div class="audibit-badge">
        <div class="audibit-icon">⚠️</div>
        <div class="audibit-content">
          <div class="audibit-title">Issues Detected</div>
          <div class="audibit-count">${r.total} issue${r.total!==1?"s":""} found</div>
        </div>
      </div>
    `,i.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_DEVTOOLS"})})}I(n,null)}function I(n,t){const e=document.getElementById("audibit-overlay-container");if(!e||!e.shadowRoot)return;const i=e.shadowRoot.getElementById("audibit-root");if(i)if(t&&t.status!=="idle"){const o=R(t.agentType),r=t.status==="bridging",s=r?"linear-gradient(135deg, #4c1d95 0%, #7c3aed 100%)":"linear-gradient(135deg, #1e293b 0%, #0f172a 100%)";i.style.background=s,i.innerHTML=`
      <div class="audibit-badge">
        <div class="audibit-icon">${o}</div>
        <div class="audibit-content">
          <div class="audibit-title">${t.agentType.toUpperCase()} Agent</div>
          <div class="audibit-count">${t.message}</div>
          ${t.progress!==void 0||r?`
            <div style="width: 100%; height: 4px; background: rgba(255,255,255,0.1); border-radius: 2px; margin-top: 4px; overflow: hidden;">
              <div style="width: ${t.progress||100}%; height: 100%; background: ${r?"#a78bfa":"#3b82f6"}; transition: width 0.3s ease; ${r?"animation: audibit-shimmer 2s infinite linear;":""}"></div>
            </div>
          `:""}
        </div>
      </div>
    `}else{const o=v(n);i.style.background="linear-gradient(135deg, #667eea 0%, #764ba2 100%)",i.innerHTML=`
      <div class="audibit-badge">
        <div class="audibit-icon">⚠️</div>
        <div class="audibit-content">
          <div class="audibit-title">Issues Detected</div>
          <div class="audibit-count">${o.total} issue${o.total!==1?"s":""} found</div>
        </div>
      </div>
    `}}function R(n){switch(n){case"ui":return"🎨";case"ux":return"🧠";case"dom":return"🏗️";case"security":return"🛡️";default:return"🤖"}}chrome.runtime.onMessage.addListener((n,t,e)=>{if(n.type==="PING")return e({pong:!0}),!0;if(n.type==="AUDIT_COMPLETE")console.log("Audit complete, showing results:",n.results);else if(n.type==="AUDIT_ERROR")console.log("Audit error:",n.error),V(n.error,n.details);else if(n.type==="REMOVE_OVERLAY"){const i=document.getElementById("audibit-overlay-container");i&&i.remove()}else if(n.type==="REMOVE_ERROR_MODAL"){const i=document.getElementById("audibit-error-modal-container");i&&i.remove()}else if(n.type==="GET_DOM"){const i=document.documentElement.outerHTML;return e({dom:i}),!0}else n.type==="HIGHLIGHT_ELEMENT"?H(n.selector):n.type==="AGENT_STATUS"&&(C(f),I(f,n.status))});function H(n){document.querySelectorAll(".audibit-highlight").forEach(t=>{t.classList.remove("audibit-highlight")});try{const t=document.querySelector(n);if(t){if(t.classList.add("audibit-highlight"),t.scrollIntoView({behavior:"smooth",block:"center"}),!document.getElementById("audibit-highlight-styles")){const e=document.createElement("style");e.id="audibit-highlight-styles",e.textContent=`
          .audibit-highlight {
            outline: 3px solid #228be6 !important;
            outline-offset: 2px !important;
            background: rgba(34, 139, 230, 0.1) !important;
            animation: audibit-pulse 1s ease-in-out 3;
          }
          @keyframes audibit-pulse {
            0%, 100% { outline-color: #228be6; }
            50% { outline-color: #4dabf7; }
          }
        `,document.head.appendChild(e)}setTimeout(()=>{t.classList.remove("audibit-highlight")},3e3)}}catch(t){console.error("Failed to highlight element:",t)}}function V(n,t){const e=document.getElementById("audibit-error-modal-container");e&&e.remove();let i="general_error",o="Audit Failed",r=n,s,a,c;if(n.includes("Insufficient USDC balance")||n.includes("Insufficient funds")){i="insufficient_funds",o="Insufficient Funds";const x=n.match(/wallet address: (0x[a-fA-F0-9]{40})/);x&&(s=x[1]);const k=n.match(/Required: ([\d.]+) USDC/);k&&(a=k[1]);const A=n.match(/Current: ([\d.]+) USDC/);A&&(c=A[1]),r="Your wallet does not have enough USDC to complete this audit."}else n.includes("Insufficient compute credits")?(i="insufficient_credits",o="Insufficient Credits",r="You need more compute credits to run this agentic audit."):n.includes("Gemini API")||n.includes("rate limit")||n.includes("API key")?(i="api_error",o="AI Service Error",r=n):(n.includes("Network error")||n.includes("fetch failed")||n.includes("connection"))&&(i="network_error",o="Connection Error",r=n);const l=document.createElement("div");l.id="audibit-error-modal-container",document.body.appendChild(l);const p=j({title:o,message:r,type:i,walletAddress:s,requiredAmount:a,currentBalance:c});l.innerHTML=p;const u=l.querySelector(".audibit-error-close"),h=l.querySelector(".audibit-error-overlay"),m=l.querySelector(".audibit-error-btn-primary"),g=l.querySelector(".audibit-error-btn-secondary"),y=()=>{l.remove()};u==null||u.addEventListener("click",y),h==null||h.addEventListener("click",y),g==null||g.addEventListener("click",y),i==="insufficient_funds"&&s&&(m==null||m.addEventListener("click",()=>{window.open(`https://faucet.circle.com?address=${s}&network=arc-testnet`,"_blank")}));const b=l.querySelector(".audibit-copy-btn");b&&s&&b.addEventListener("click",()=>{navigator.clipboard.writeText(s);const x=b.textContent;b.textContent="✓ Copied!",setTimeout(()=>{b.textContent=x},2e3)})}function j(n){const{title:t,message:e,type:i,walletAddress:o,requiredAmount:r,currentBalance:s}=n;let a="⚠️",c="";return i==="insufficient_funds"?(a="💰",c=`
      <p class="audibit-error-message">${e}</p>
      
      ${r&&s?`
        <div class="audibit-balance-info">
          <div class="audibit-balance-row">
            <span class="audibit-label">Required:</span>
            <span class="audibit-value audibit-required">${r} USDC</span>
          </div>
          <div class="audibit-balance-row">
            <span class="audibit-label">Current:</span>
            <span class="audibit-value audibit-current">${s} USDC</span>
          </div>
        </div>
      `:""}

      ${o?`
        <div class="audibit-instructions">
          <h3>How to add funds:</h3>
          <ol>
            <li>Visit <a href="https://faucet.circle.com" target="_blank" rel="noopener noreferrer">Circle Faucet</a></li>
            <li>Enter your wallet address:
              <div class="audibit-wallet-address">
                <code>${o}</code>
                <button class="audibit-copy-btn" title="Copy address">📋</button>
              </div>
            </li>
            <li>Select <strong>Arc Testnet</strong></li>
            <li>Request testnet USDC</li>
            <li>Wait 10-30 seconds for tokens to arrive</li>
            <li>Try your audit again</li>
          </ol>
        </div>
        <div class="audibit-actions">
          <button class="audibit-error-btn audibit-error-btn-primary">Open Faucet</button>
          <button class="audibit-error-btn audibit-error-btn-secondary">Close</button>
        </div>
      `:`
        <div class="audibit-actions">
          <button class="audibit-error-btn audibit-error-btn-secondary">Close</button>
        </div>
      `}
    `):i==="insufficient_credits"?(a="⚡",c=`
      <p class="audibit-error-message">${e}</p>
      <div class="audibit-instructions">
        <h3>How to get credits:</h3>
        <ul>
          <li>Open the AudiBit extension</li>
          <li>Go to the <strong>Marketplace</strong> or <strong>Wallet</strong> tab</li>
          <li>Click <strong>Purchase Credits</strong></li>
          <li>Credits are consumed per audit to power the AI agents</li>
        </ul>
      </div>
      <div class="audibit-actions">
        <button class="audibit-error-btn audibit-error-btn-secondary">Close</button>
      </div>
    `):i==="api_error"?(a="🤖",c=`
      <p class="audibit-error-message">${e}</p>
      <div class="audibit-instructions">
        <h3>Possible causes:</h3>
        <ul>
          <li>Gemini API rate limit exceeded</li>
          <li>Network connectivity issues</li>
          <li>API key configuration problem</li>
        </ul>
        <p class="audibit-help-text">Please wait a moment and try again. If the problem persists, contact support.</p>
      </div>
      <div class="audibit-actions">
        <button class="audibit-error-btn audibit-error-btn-secondary">Close</button>
      </div>
    `):i==="network_error"?(a="🌐",c=`
      <p class="audibit-error-message">${e}</p>
      <div class="audibit-instructions">
        <h3>Troubleshooting:</h3>
        <ul>
          <li>Check your internet connection</li>
          <li>Verify Firebase emulator is running</li>
          <li>Ensure backend services are accessible</li>
        </ul>
      </div>
      <div class="audibit-actions">
        <button class="audibit-error-btn audibit-error-btn-secondary">Close</button>
      </div>
    `):c=`
      <p class="audibit-error-message">${e}</p>
      <div class="audibit-actions">
        <button class="audibit-error-btn audibit-error-btn-secondary">Close</button>
      </div>
    `,`
    <div class="audibit-error-overlay"></div>
    <div class="audibit-error-modal">
      <button class="audibit-error-close">×</button>
      <div class="audibit-error-content">
        <div class="audibit-error-icon">${a}</div>
        <h2>${t}</h2>
        ${c}
      </div>
    </div>
    ${G()}
  `}function G(){return`
    <style>
      .audibit-error-overlay {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        right: 0 !important;
        bottom: 0 !important;
        background: rgba(0, 0, 0, 0.7) !important;
        backdrop-filter: blur(4px) !important;
        z-index: 2147483646 !important;
        animation: audibitFadeIn 0.2s ease-out !important;
      }

      @keyframes audibitFadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }

      .audibit-error-modal {
        position: fixed !important;
        top: 50% !important;
        left: 50% !important;
        transform: translate(-50%, -50%) !important;
        width: 90% !important;
        max-width: 500px !important;
        max-height: 80vh !important;
        background: #1a1b1e !important;
        border-radius: 16px !important;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5) !important;
        z-index: 2147483647 !important;
        overflow: hidden !important;
        animation: audibitSlideIn 0.3s ease-out !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
      }

      @keyframes audibitSlideIn {
        from {
          opacity: 0;
          transform: translate(-50%, -45%);
        }
        to {
          opacity: 1;
          transform: translate(-50%, -50%);
        }
      }

      .audibit-error-close {
        position: absolute !important;
        top: 16px !important;
        right: 16px !important;
        background: none !important;
        border: none !important;
        color: #909296 !important;
        font-size: 28px !important;
        cursor: pointer !important;
        line-height: 1 !important;
        padding: 0 !important;
        width: 32px !important;
        height: 32px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        border-radius: 4px !important;
        transition: all 0.2s !important;
      }

      .audibit-error-close:hover {
        background: #373a40 !important;
        color: #e9ecef !important;
      }

      .audibit-error-content {
        padding: 32px !important;
        color: #ffffff !important;
        overflow-y: auto !important;
        max-height: 80vh !important;
      }

      .audibit-error-icon {
        font-size: 48px !important;
        text-align: center !important;
        margin-bottom: 16px !important;
      }

      .audibit-error-modal h2 {
        font-size: 24px !important;
        font-weight: 700 !important;
        margin: 0 0 16px 0 !important;
        text-align: center !important;
        color: #e9ecef !important;
      }

      .audibit-error-message {
        font-size: 14px !important;
        line-height: 1.6 !important;
        color: #adb5bd !important;
        text-align: center !important;
        margin: 0 0 24px 0 !important;
      }

      .audibit-balance-info {
        background: #25262b !important;
        border-radius: 8px !important;
        padding: 16px !important;
        margin-bottom: 24px !important;
      }

      .audibit-balance-row {
        display: flex !important;
        justify-content: space-between !important;
        align-items: center !important;
        padding: 8px 0 !important;
      }

      .audibit-balance-row:not(:last-child) {
        border-bottom: 1px solid #333 !important;
      }

      .audibit-label {
        font-size: 13px !important;
        color: #909296 !important;
        font-weight: 500 !important;
      }

      .audibit-value {
        font-size: 14px !important;
        font-weight: 700 !important;
        font-family: monospace !important;
      }

      .audibit-required {
        color: #fa5252 !important;
      }

      .audibit-current {
        color: #ffd43b !important;
      }

      .audibit-instructions {
        background: #25262b !important;
        border-radius: 8px !important;
        padding: 16px !important;
        margin-bottom: 24px !important;
        text-align: left !important;
      }

      .audibit-instructions h3 {
        font-size: 14px !important;
        font-weight: 600 !important;
        margin: 0 0 12px 0 !important;
        color: #4dabf7 !important;
      }

      .audibit-instructions ol,
      .audibit-instructions ul {
        margin: 0 !important;
        padding-left: 20px !important;
        color: #adb5bd !important;
      }

      .audibit-instructions li {
        font-size: 13px !important;
        line-height: 1.6 !important;
        margin-bottom: 8px !important;
      }

      .audibit-instructions a {
        color: #4dabf7 !important;
        text-decoration: none !important;
        font-weight: 600 !important;
      }

      .audibit-instructions a:hover {
        text-decoration: underline !important;
      }

      .audibit-instructions strong {
        color: #e9ecef !important;
        font-weight: 600 !important;
      }

      .audibit-wallet-address {
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
        background: #2c2e33 !important;
        padding: 8px 12px !important;
        border-radius: 6px !important;
        margin-top: 8px !important;
      }

      .audibit-wallet-address code {
        flex: 1 !important;
        font-size: 11px !important;
        color: #82c91e !important;
        word-break: break-all !important;
        font-family: 'Courier New', monospace !important;
      }

      .audibit-copy-btn {
        background: #373a40 !important;
        border: none !important;
        padding: 4px 8px !important;
        border-radius: 4px !important;
        cursor: pointer !important;
        font-size: 14px !important;
        transition: all 0.2s !important;
        flex-shrink: 0 !important;
      }

      .audibit-copy-btn:hover {
        background: #4dabf7 !important;
        transform: scale(1.1) !important;
      }

      .audibit-help-text {
        font-size: 12px !important;
        color: #909296 !important;
        margin-top: 12px !important;
        font-style: italic !important;
      }

      .audibit-actions {
        display: flex !important;
        gap: 12px !important;
        justify-content: center !important;
      }

      .audibit-error-btn {
        padding: 12px 24px !important;
        border: none !important;
        border-radius: 8px !important;
        font-size: 14px !important;
        font-weight: 600 !important;
        cursor: pointer !important;
        transition: all 0.2s !important;
        font-family: inherit !important;
      }

      .audibit-error-btn-primary {
        background: #228be6 !important;
        color: white !important;
      }

      .audibit-error-btn-primary:hover {
        background: #1c7ed6 !important;
        transform: translateY(-1px) !important;
      }

      .audibit-error-btn-secondary {
        background: #373a40 !important;
        color: #e9ecef !important;
      }

      .audibit-error-btn-secondary:hover {
        background: #495057 !important;
      }

      .audibit-error-content::-webkit-scrollbar {
        width: 8px !important;
      }

      .audibit-error-content::-webkit-scrollbar-track {
        background: #25262b !important;
      }

      .audibit-error-content::-webkit-scrollbar-thumb {
        background: #495057 !important;
        border-radius: 4px !important;
      }

      .audibit-error-content::-webkit-scrollbar-thumb:hover {
        background: #5c5f66 !important;
      }
    </style>
  `}W.start();chrome.runtime.onMessage.addListener((n,t,e)=>{if(n.type==="ENABLE_AUDIT_MODE"){const i=window.__AUDIT_WAND__;return i?(i.enableAuditMode(n.agentType),e({success:!0})):e({success:!1,error:"Audit Wand not available"}),!0}if(n.type==="DISABLE_AUDIT_MODE"){const i=window.__AUDIT_WAND__;return i&&(i.disableAuditMode(),e({success:!0})),!0}if(n.type==="PING")return e({pong:!0}),!0;if(n.type==="GET_DOM")return e({dom:document.documentElement.outerHTML,url:window.location.href,title:document.title}),!0;if(n.type==="WAND_TOGGLE"){const i=window.__WAND_OVERLAY__;if(i){const o=i.toggle();e({active:o})}else document.dispatchEvent(new KeyboardEvent("keydown",{key:" ",code:"Space",ctrlKey:!0,bubbles:!0})),e({active:!0});return!0}});
})()
