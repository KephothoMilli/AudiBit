import{c as w,j as e,r as n}from"./client-DPvrtzYh.js";const S=()=>{const[o,u]=n.useState(null),[r,x]=n.useState(null),[c,b]=n.useState("all"),[p,g]=n.useState("all"),[l,m]=n.useState(!1);n.useEffect(()=>{const i=t=>{if(t.type==="AUDIT_COMPLETE"){const a=t.results.issues.map((s,k)=>({id:`issue-${k}`,type:s.type||"ux",severity:s.severity,title:s.title,description:s.description,recommendation:s.recommendation||"No recommendation provided",selector:s.element||s.selector||"N/A",fix:{type:"code",recommendation:s.recommendation||"No recommendation provided",codeSnippet:s.codeSnippet||f(s)},cve:s.cve}));u({auditId:Date.now().toString(),issues:a,creditsUsed:1,timestamp:new Date().toISOString()}),m(!1),a.length>0&&x(a[0])}else t.type==="AUDIT_ERROR"&&(m(!1),console.error("Audit error:",t.error))};return chrome.runtime.onMessage.addListener(i),()=>chrome.runtime.onMessage.removeListener(i)},[]);const f=i=>{const t=i.element||i.selector||"element";if(i.type==="accessibility"){if(i.title.toLowerCase().includes("alt text"))return'<img src="..." alt="Descriptive text here" />';if(i.title.toLowerCase().includes("aria"))return`<button aria-label="Descriptive label">
  ${t}
</button>`;if(i.title.toLowerCase().includes("label"))return`<label for="input-id">Label text</label>
<input id="input-id" type="text" />`}return i.type==="responsive"?`/* Use relative units instead of fixed pixels */
.${t} {
  width: 100%;
  max-width: 600px;
  font-size: 1rem;
}`:`<!-- Fix for: ${i.title} -->
<!-- ${i.recommendation} -->`},y=()=>{m(!0),chrome.tabs.query({active:!0,currentWindow:!0},i=>{var t;(t=i[0])!=null&&t.id&&chrome.tabs.sendMessage(i[0].id,{type:"GET_DOM"},a=>{a!=null&&a.dom&&chrome.runtime.sendMessage({type:"TRIGGER_AUDIT",auditType:"uiux",url:i[0].url||"",dom:a.dom})})})},v=i=>{navigator.clipboard.writeText(i)},j=i=>{chrome.tabs.query({active:!0,currentWindow:!0},t=>{var a;(a=t[0])!=null&&a.id&&chrome.tabs.sendMessage(t[0].id,{type:"HIGHLIGHT_ELEMENT",selector:i})})},N=(o==null?void 0:o.issues.filter(i=>{const t=c==="all"||i.type===c,a=p==="all"||i.severity===p;return t&&a}))||[],d=(o==null?void 0:o.issues.reduce((i,t)=>(i[t.severity]=(i[t.severity]||0)+1,i),{}))||{};return e.jsxs("div",{className:"devtools-panel",children:[e.jsxs("header",{className:"panel-header",children:[e.jsxs("div",{className:"brand",children:[e.jsx("span",{className:"logo",children:"A"}),e.jsx("h1",{children:"Audibit DevTools"})]}),e.jsx("button",{onClick:y,disabled:l,className:"audit-btn",children:l?"Analyzing...":"Run Audit"})]}),!o&&!l&&e.jsxs("div",{className:"empty-state",children:[e.jsx("div",{className:"empty-icon",children:"🔍"}),e.jsx("h2",{children:"No Audit Results Yet"}),e.jsx("p",{children:'Click "Run Audit" to analyze the current page for UI/UX and accessibility issues.'})]}),l&&e.jsxs("div",{className:"loading-state",children:[e.jsx("div",{className:"spinner"}),e.jsx("p",{children:"Analyzing page with AI..."})]}),o&&!l&&e.jsxs("div",{className:"panel-content",children:[e.jsxs("aside",{className:"sidebar",children:[e.jsxs("div",{className:"summary-cards",children:[e.jsxs("div",{className:"summary-card critical",children:[e.jsx("span",{className:"count",children:d.critical||0}),e.jsx("span",{className:"label",children:"Critical"})]}),e.jsxs("div",{className:"summary-card high",children:[e.jsx("span",{className:"count",children:d.high||0}),e.jsx("span",{className:"label",children:"High"})]}),e.jsxs("div",{className:"summary-card medium",children:[e.jsx("span",{className:"count",children:d.medium||0}),e.jsx("span",{className:"label",children:"Medium"})]}),e.jsxs("div",{className:"summary-card low",children:[e.jsx("span",{className:"count",children:d.low||0}),e.jsx("span",{className:"label",children:"Low"})]})]}),e.jsxs("div",{className:"filters",children:[e.jsxs("select",{value:c,onChange:i=>b(i.target.value),children:[e.jsx("option",{value:"all",children:"All Types"}),e.jsx("option",{value:"accessibility",children:"Accessibility"}),e.jsx("option",{value:"ux",children:"UX"}),e.jsx("option",{value:"responsive",children:"Responsive"}),e.jsx("option",{value:"security",children:"Security"})]}),e.jsxs("select",{value:p,onChange:i=>g(i.target.value),children:[e.jsx("option",{value:"all",children:"All Severities"}),e.jsx("option",{value:"critical",children:"Critical"}),e.jsx("option",{value:"high",children:"High"}),e.jsx("option",{value:"medium",children:"Medium"}),e.jsx("option",{value:"low",children:"Low"})]})]}),e.jsx("div",{className:"issues-list",children:N.map(i=>e.jsxs("div",{className:`issue-item ${(r==null?void 0:r.id)===i.id?"active":""}`,onClick:()=>x(i),children:[e.jsx("div",{className:`severity-dot ${i.severity}`}),e.jsxs("div",{className:"issue-info",children:[e.jsx("div",{className:"issue-title",children:i.title}),e.jsx("div",{className:"issue-type",children:i.type})]})]},i.id))})]}),e.jsx("main",{className:"detail-panel",children:r?e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"detail-header",children:[e.jsx("div",{className:`severity-badge ${r.severity}`,children:r.severity.toUpperCase()}),e.jsx("span",{className:"type-badge",children:r.type})]}),e.jsx("h2",{children:r.title}),e.jsx("p",{className:"description",children:r.description}),e.jsxs("div",{className:"section",children:[e.jsx("h3",{children:"Affected Element"}),e.jsxs("div",{className:"code-block",children:[e.jsx("code",{children:r.selector}),e.jsx("button",{onClick:()=>j(r.selector),className:"action-btn",children:"Highlight"})]})]}),e.jsxs("div",{className:"section",children:[e.jsx("h3",{children:"Recommended Fix"}),e.jsx("p",{className:"recommendation",children:r.fix.recommendation}),e.jsxs("div",{className:"code-block",children:[e.jsx("pre",{children:e.jsx("code",{children:r.fix.codeSnippet})}),e.jsx("button",{onClick:()=>v(r.fix.codeSnippet),className:"action-btn",children:"Copy"})]})]}),r.cve&&e.jsxs("div",{className:"section cve-section",children:[e.jsx("h3",{children:"Security Reference"}),e.jsx("a",{href:`https://cve.mitre.org/cgi-bin/cvename.cgi?name=${r.cve}`,target:"_blank",rel:"noopener noreferrer",children:r.cve})]})]}):e.jsx("div",{className:"no-selection",children:e.jsx("p",{children:"Select an issue from the list to view details"})})})]}),e.jsx("style",{children:`
        .devtools-panel {
          background: #1a1b1e;
          color: #e9ecef;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          height: 100vh;
          display: flex;
          flex-direction: column;
          overflow: hidden;
        }

        .panel-header {
          padding: 12px 16px;
          background: #25262b;
          border-bottom: 1px solid #373a40;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .brand {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .logo {
          background: #228be6;
          color: white;
          width: 24px;
          height: 24px;
          border-radius: 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
        }

        h1 {
          font-size: 16px;
          margin: 0;
          color: #e9ecef;
        }

        .audit-btn {
          padding: 8px 16px;
          background: #228be6;
          color: white;
          border: none;
          border-radius: 6px;
          font-weight: bold;
          cursor: pointer;
          transition: background 0.2s;
        }

        .audit-btn:hover:not(:disabled) {
          background: #1c7ed6;
        }

        .audit-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .empty-state, .loading-state {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: calc(100vh - 60px);
          text-align: center;
          padding: 40px;
        }

        .empty-icon {
          font-size: 64px;
          margin-bottom: 16px;
        }

        .empty-state h2 {
          margin: 0 0 8px 0;
          color: #e9ecef;
        }

        .empty-state p {
          color: #909296;
          max-width: 400px;
        }

        .spinner {
          width: 40px;
          height: 40px;
          border: 4px solid #373a40;
          border-top-color: #228be6;
          border-radius: 50%;
          animation: spin 1s linear infinite;
          margin-bottom: 16px;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        .loading-state p {
          color: #909296;
        }

        .panel-content {
          display: flex;
          flex: 1;
          overflow: hidden;
        }

        .sidebar {
          width: 320px;
          background: #25262b;
          border-right: 1px solid #373a40;
          display: flex;
          flex-direction: column;
          overflow: hidden;
        }

        .summary-cards {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 8px;
          padding: 12px;
          border-bottom: 1px solid #373a40;
        }

        .summary-card {
          padding: 12px;
          border-radius: 6px;
          text-align: center;
        }

        .summary-card.critical { background: rgba(201, 42, 42, 0.2); border: 1px solid #c92a2a; }
        .summary-card.high { background: rgba(230, 119, 0, 0.2); border: 1px solid #e67700; }
        .summary-card.medium { background: rgba(250, 176, 5, 0.2); border: 1px solid #fab005; }
        .summary-card.low { background: rgba(92, 148, 13, 0.2); border: 1px solid #5c940d; }

        .summary-card .count {
          display: block;
          font-size: 24px;
          font-weight: bold;
          margin-bottom: 4px;
        }

        .summary-card .label {
          display: block;
          font-size: 11px;
          text-transform: uppercase;
          opacity: 0.8;
        }

        .filters {
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 8px;
          border-bottom: 1px solid #373a40;
        }

        .filters select {
          padding: 8px;
          background: #1a1b1e;
          color: #e9ecef;
          border: 1px solid #373a40;
          border-radius: 4px;
          font-size: 13px;
        }

        .issues-list {
          flex: 1;
          overflow-y: auto;
          padding: 8px;
        }

        .issue-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px;
          border-radius: 6px;
          cursor: pointer;
          transition: background 0.2s;
          margin-bottom: 4px;
        }

        .issue-item:hover {
          background: #2c2e33;
        }

        .issue-item.active {
          background: #373a40;
        }

        .severity-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          flex-shrink: 0;
        }

        .severity-dot.critical { background: #c92a2a; }
        .severity-dot.high { background: #e67700; }
        .severity-dot.medium { background: #fab005; }
        .severity-dot.low { background: #5c940d; }

        .issue-info {
          flex: 1;
          min-width: 0;
        }

        .issue-title {
          font-size: 13px;
          font-weight: 500;
          margin-bottom: 4px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .issue-type {
          font-size: 11px;
          color: #909296;
          text-transform: capitalize;
        }

        .detail-panel {
          flex: 1;
          overflow-y: auto;
          padding: 24px;
        }

        .detail-header {
          display: flex;
          gap: 8px;
          margin-bottom: 16px;
        }

        .severity-badge {
          padding: 4px 12px;
          border-radius: 4px;
          font-size: 11px;
          font-weight: bold;
        }

        .severity-badge.critical { background: #c92a2a; }
        .severity-badge.high { background: #e67700; }
        .severity-badge.medium { background: #fab005; color: #000; }
        .severity-badge.low { background: #5c940d; }

        .type-badge {
          padding: 4px 12px;
          border-radius: 4px;
          font-size: 11px;
          background: #373a40;
          text-transform: capitalize;
        }

        .detail-panel h2 {
          font-size: 24px;
          margin: 0 0 12px 0;
          color: #e9ecef;
        }

        .description {
          color: #adb5bd;
          line-height: 1.6;
          margin-bottom: 24px;
        }

        .section {
          margin-bottom: 24px;
        }

        .section h3 {
          font-size: 14px;
          text-transform: uppercase;
          color: #909296;
          margin: 0 0 12px 0;
          letter-spacing: 0.5px;
        }

        .recommendation {
          color: #adb5bd;
          line-height: 1.6;
          margin-bottom: 12px;
        }

        .code-block {
          background: #25262b;
          border: 1px solid #373a40;
          border-radius: 6px;
          padding: 12px;
          position: relative;
        }

        .code-block code {
          color: #82c91e;
          font-family: 'Courier New', monospace;
          font-size: 13px;
        }

        .code-block pre {
          margin: 0;
          overflow-x: auto;
        }

        .code-block .action-btn {
          position: absolute;
          top: 8px;
          right: 8px;
          padding: 4px 12px;
          background: #373a40;
          color: #e9ecef;
          border: none;
          border-radius: 4px;
          font-size: 11px;
          cursor: pointer;
          transition: background 0.2s;
        }

        .code-block .action-btn:hover {
          background: #495057;
        }

        .cve-section a {
          color: #4dabf7;
          text-decoration: none;
          font-family: monospace;
        }

        .cve-section a:hover {
          text-decoration: underline;
        }

        .no-selection {
          display: flex;
          align-items: center;
          justify-content: center;
          height: 100%;
          color: #909296;
        }
      `})]})},h=document.getElementById("root");h&&w.createRoot(h).render(e.jsx(S,{}));
