import{r as o,j as e,R as De,c as Ee}from"./client-DPvrtzYh.js";const $e=({onComplete:a})=>{const[r,s]=o.useState("logo");return o.useEffect(()=>{const c=setTimeout(()=>s("brand"),500),i=setTimeout(()=>s("tagline"),1100),p=setTimeout(()=>s("exit"),2200),z=setTimeout(()=>a(),2800);return()=>{clearTimeout(c),clearTimeout(i),clearTimeout(p),clearTimeout(z)}},[a]),e.jsxs("div",{className:`splash ${r==="exit"?"splash--exit":""}`,children:[e.jsx("div",{className:"splash__bg"}),e.jsxs("div",{className:`splash__content ${r!=="logo"?"splash__content--up":""}`,children:[e.jsxs("div",{className:"splash__logo",children:[e.jsxs("svg",{width:"48",height:"48",viewBox:"0 0 48 48",fill:"none",children:[e.jsx("rect",{width:"48",height:"48",rx:"12",fill:"url(#logoAzure)"}),e.jsx("path",{d:"M24 12L36 34H12L24 12Z",fill:"white",opacity:"0.95"}),e.jsx("path",{d:"M24 24L30 34H18L24 24Z",fill:"#1e1b4b",opacity:"0.4"}),e.jsx("defs",{children:e.jsxs("linearGradient",{id:"logoAzure",x1:"0",y1:"0",x2:"48",y2:"48",children:[e.jsx("stop",{offset:"0%",stopColor:"#3b82f6"}),e.jsx("stop",{offset:"100%",stopColor:"#4338ca"})]})})]}),e.jsx("div",{className:"splash__logo-shadow"})]}),e.jsxs("div",{className:`splash__brand ${r==="brand"||r==="tagline"?"splash__brand--visible":""}`,children:[e.jsxs("h1",{className:"splash__brand-name",children:["Audi",e.jsx("span",{className:"text-azure",children:"Bit"})]}),e.jsx("p",{className:`splash__tagline ${r==="tagline"?"splash__tagline--visible":""}`,children:"Economic OS for Web Audits"})]})]}),e.jsx("div",{className:`splash__loader ${r==="tagline"||r==="exit"?"splash__loader--visible":""}`,children:e.jsx("div",{className:"splash__loader-bar"})}),e.jsx("style",{children:`
        .splash {
          position: fixed;
          top: 0;
          left: 0;
          width: 420px;
          height: 600px;
          background: #ffffff;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          z-index: 9999;
          transition: opacity 0.6s ease;
          overflow: hidden;
          font-family: 'Inter', -apple-system, sans-serif;
        }
        .splash--exit { opacity: 0; pointer-events: none; }

        .splash__bg {
          position: absolute;
          inset: 0;
          background-image: radial-gradient(circle at 50% 50%, #f8fafc 0%, #ffffff 100%);
          opacity: 0.6;
        }

        .splash__content {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 24px;
          transition: transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .splash__content--up { transform: translateY(-16px); }

        .splash__logo {
          position: relative;
          filter: drop-shadow(0 10px 15px rgba(59, 130, 246, 0.2));
          animation: logoScale 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        @keyframes logoScale {
          from { transform: scale(0.6); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }

        .splash__logo-shadow {
          position: absolute;
          bottom: -10px;
          left: 50%;
          transform: translateX(-50%);
          width: 30px;
          height: 4px;
          background: rgba(0, 0, 0, 0.05);
          filter: blur(4px);
          border-radius: 50%;
        }

        .splash__brand {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          opacity: 0;
          transform: translateY(12px);
          transition: all 0.6s ease;
        }
        .splash__brand--visible { opacity: 1; transform: translateY(0); }

        .splash__brand-name {
          font-size: 32px;
          font-weight: 800;
          color: #0f172a;
          letter-spacing: -1px;
        }
        .text-azure { color: #3b82f6; }

        .splash__tagline {
          font-size: 13px;
          font-weight: 500;
          color: #64748b;
          letter-spacing: 0.5px;
          opacity: 0;
          transition: opacity 0.5s ease 0.2s;
        }
        .splash__tagline--visible { opacity: 1; }

        .splash__loader {
          position: absolute;
          bottom: 60px;
          width: 120px;
          height: 3px;
          background: #f1f5f9;
          border-radius: 10px;
          overflow: hidden;
          opacity: 0;
          transition: opacity 0.3s ease;
        }
        .splash__loader--visible { opacity: 1; }

        .splash__loader-bar {
          height: 100%;
          background: linear-gradient(90deg, #3b82f6, #6366f1);
          width: 0%;
          border-radius: 10px;
          animation: fillLoader 1.5s ease-in-out forwards;
        }
        @keyframes fillLoader {
          from { width: 0%; }
          to { width: 100%; }
        }
      `})]})},S="http://127.0.0.1:5001/w3bn3xt/us-central1",Le="AudibitWalletDB",Pe=1,C="wallets";function G(){return new Promise((a,r)=>{const s=indexedDB.open(Le,Pe);s.onerror=()=>r(s.error),s.onsuccess=()=>a(s.result),s.onupgradeneeded=c=>{const i=c.target.result;i.objectStoreNames.contains(C)||i.createObjectStore(C,{keyPath:"address"}).createIndex("createdAt","createdAt",{unique:!1})}})}async function P(a){try{const r=await G(),s=r.transaction([C],"readwrite");return s.objectStore(C).put(a),new Promise((i,p)=>{s.oncomplete=()=>{r.close(),i()},s.onerror=()=>{r.close(),p(s.error)}})}catch(r){console.warn("IndexedDB save failed, falling back to localStorage:",r),localStorage.setItem(`audibit_wallet_${a.address}`,JSON.stringify(a))}}async function Re(a){try{const r=await G(),i=r.transaction([C],"readonly").objectStore(C).get(a);return new Promise((p,z)=>{i.onsuccess=()=>{r.close(),p(i.result||null)},i.onerror=()=>{r.close(),z(i.error)}})}catch(r){console.warn("IndexedDB read failed, falling back to localStorage:",r);const s=localStorage.getItem(`audibit_wallet_${a}`);return s?JSON.parse(s):null}}async function Oe(){try{const a=await G(),c=a.transaction([C],"readonly").objectStore(C).getAll();return new Promise((i,p)=>{c.onsuccess=()=>{a.close(),i(c.result||[])},c.onerror=()=>{a.close(),p(c.error)}})}catch(a){console.warn("IndexedDB read failed, falling back to localStorage:",a);const r=[];for(let s=0;s<localStorage.length;s++){const c=localStorage.key(s);if(c!=null&&c.startsWith("audibit_wallet_")){const i=localStorage.getItem(c);i&&r.push(JSON.parse(i))}}return r}}async function Me(){try{console.log("Creating Circle wallet..."),console.log("Functions URL:",S);const a=await fetch(`${S}/createWallet`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({blockchain:"ARC-TESTNET"})});if(console.log("Response status:",a.status),console.log("Response headers:",Object.fromEntries(a.headers.entries())),!a.ok){const s=await a.json().catch(()=>({error:"Failed to create wallet",message:`HTTP ${a.status}: ${a.statusText}`}));throw console.error("Wallet creation failed:",s),a.status===500?new Error(s.message||"Server error. Please ensure Circle API credentials are configured in Firebase Functions."):a.status===404?new Error("Wallet creation endpoint not found. Please ensure Firebase Functions are deployed."):new Error(s.message||s.error||"Failed to create wallet")}const r=await a.json();return console.log("Wallet created successfully:",r.wallet),r.wallet}catch(a){throw console.error("Error creating Circle wallet:",a),a instanceof TypeError&&a.message.includes("fetch")?(console.error("Network error - possible causes:"),console.error("1. Firebase Functions not running"),console.error("2. CORS issue"),console.error("3. Invalid Functions URL:",S),new Error("Network error: Cannot connect to backend. Please ensure Firebase Functions are running.")):a instanceof Error?a:new Error("Failed to create wallet. Please check your internet connection and try again.")}}async function Ge(a){try{const r=await fetch(`${S}/getWalletBalance`,{method:"POST",headers:{"Content-Type":"application/json","X-Wallet-Address":a}});if(!r.ok){const c=await r.json().catch(()=>({message:"Failed to get balance"}));throw new Error(c.message||"Failed to get balance")}return(await r.json()).balances}catch(r){throw console.error("Error getting wallet balance:",r),r}}async function xe(){try{const a=await chrome.storage.local.get(["circleWalletAddress"]);if(a.circleWalletAddress){const i=a.circleWalletAddress;console.log("Wallet found in chrome.storage:",i);const p=await Re(i);if(p)return p.lastUsed=Date.now(),await P(p),i}const r=await Oe();if(r.length>0){const i=r.sort((p,z)=>z.lastUsed-p.lastUsed)[0];return console.log("Wallet found in IndexedDB:",i.address),await chrome.storage.local.set({circleWalletAddress:i.address,circleWalletId:i.id,circleWalletBlockchain:i.blockchain}),i.lastUsed=Date.now(),await P(i),i.address}console.log("No existing wallet found, creating new one...");const s=await Me(),c={...s,createdAt:Date.now(),lastUsed:Date.now()};return await P(c),console.log("Wallet saved to IndexedDB"),await chrome.storage.local.set({circleWalletAddress:s.address,circleWalletId:s.id,circleWalletBlockchain:s.blockchain}),console.log("Wallet saved to chrome.storage"),s.address}catch(a){throw console.error("Error in getOrCreateWallet:",a),a}}async function L(){try{return(await chrome.storage.local.get(["circleWalletAddress"])).circleWalletAddress||null}catch(a){return console.error("Error getting connected wallet:",a),null}}async function fe(){try{await chrome.storage.local.remove(["circleWalletAddress","circleWalletId","circleWalletBlockchain"]),console.log("Wallet disconnected")}catch(a){throw console.error("Error disconnecting wallet:",a),a}}async function ge(a){try{const r=await fetch(`${S}/getPaymentLogs`,{method:"POST",headers:{"Content-Type":"application/json","X-Wallet-Address":a}});if(!r.ok)throw new Error("Failed to get payment logs");return(await r.json()).logs}catch(r){return console.error("Error getting payment logs:",r),[]}}async function Ye(a){try{const r=await fetch(`${S}/verifyWallet`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({walletAddress:a})});if(!r.ok){const s=await r.json().catch(()=>({message:"Failed to verify wallet"}));throw new Error(s.message||"Failed to verify wallet")}return await r.json()}catch(r){throw console.error("Error verifying wallet:",r),r}}async function qe(a){try{const r=await fetch(`${S}/importWallet`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({walletAddress:a})});if(!r.ok){const i=await r.json().catch(()=>({message:"Failed to import wallet"}));throw new Error(i.message||i.error||"Failed to import wallet")}const s=await r.json(),c={...s.wallet,createdAt:Date.now(),lastUsed:Date.now()};return await P(c),await chrome.storage.local.set({circleWalletAddress:s.wallet.address,circleWalletId:s.wallet.id,circleWalletBlockchain:s.wallet.blockchain}),s}catch(r){throw console.error("Error importing wallet:",r),r}}async function Ve(){try{const a=await fetch(`${S}/listCircleWallets`,{method:"GET",headers:{"Content-Type":"application/json"}});if(!a.ok){const r=await a.json().catch(()=>({message:"Failed to list wallets"}));throw new Error(r.message||"Failed to list wallets")}return await a.json()}catch(a){throw console.error("Error listing wallets:",a),a}}const He=({logs:a})=>e.jsxs("div",{className:"payment-log",children:[e.jsx("div",{className:"log-list",children:a.length===0?e.jsx("div",{className:"log-empty",children:"No settlements on Arc yet"}):a.map(r=>{var s;return e.jsxs("div",{className:"log-item",children:[e.jsxs("div",{className:"log-main",children:[e.jsx("div",{className:"log-desc",children:r.description}),e.jsxs("div",{className:"log-tx",children:["TX: ",(s=r.transactionId)==null?void 0:s.slice(0,12),"..."]})]}),e.jsxs("div",{className:"log-meta",children:[e.jsxs("div",{className:"log-amount",children:[(parseFloat(r.amount)||0).toFixed(4)," USDC"]}),e.jsxs("div",{className:"log-cu",children:[r.computeUnits," CU"]})]})]},r.id)})}),e.jsx("style",{children:`
        .payment-log {
          background: #ffffff;
          border-radius: 12px;
          display: flex;
          flex-direction: column;
        }
        .log-list {
          display: flex;
          flex-direction: column;
          gap: 1px;
          background: #f1f5f9;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          overflow: hidden;
        }
        .log-empty {
          background: #ffffff;
          text-align: center;
          padding: 30px 20px;
          color: #94a3b8;
          font-size: 12px;
          font-weight: 500;
        }
        .log-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px 14px;
          background: #ffffff;
          transition: background 0.2s;
        }
        .log-item:hover { background: #f8fafc; }
        
        .log-main {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        .log-desc {
          font-size: 13px;
          font-weight: 600;
          color: #1e293b;
        }
        .log-tx {
          font-size: 10px;
          color: #94a3b8;
          font-family: monospace;
        }
        
        .log-meta {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 2px;
        }
        .log-amount {
          font-size: 13px;
          font-weight: 700;
          color: #3b82f6;
        }
        .log-cu {
          font-size: 10px;
          font-weight: 600;
          color: #64748b;
          background: #f1f5f9;
          padding: 1px 6px;
          border-radius: 4px;
        }
      `})]}),Xe=({status:a})=>{if(!a||a.status==="idle")return null;const r=i=>{switch(i){case"ui":return"🎨";case"ux":return"🧠";case"dom":return"🏗️";case"security":return"🛡️";case"coordinator":return"🚀";default:return"🤖"}},s=i=>{switch(i){case"analyzing":return"#3b82f6";case"settling":return"#f59e0b";case"complete":return"#22c55e";case"error":return"#ef4444";case"bridging":return"#8b5cf6";default:return"#64748b"}},c=i=>{switch(i){case"analyzing":return"Analyzing...";case"settling":return"Settling payment...";case"complete":return"Complete";case"error":return"Error";case"bridging":return"Bridging Funds...";default:return"Processing..."}};return e.jsxs("div",{className:"agent-status-panel",children:[e.jsxs("div",{className:"status-content",children:[e.jsx("div",{className:"status-icon",children:r(a.agentType)}),e.jsxs("div",{className:"status-info",children:[e.jsxs("div",{className:"status-header",children:[e.jsxs("span",{className:"agent-name",children:[a.agentType.toUpperCase()," Agent"]}),e.jsx("span",{className:"status-badge",style:{backgroundColor:s(a.status)},children:c(a.status)})]}),e.jsx("div",{className:"status-message",children:a.message}),a.progress!==void 0&&a.status==="analyzing"&&e.jsx("div",{className:"progress-bar",children:e.jsx("div",{className:"progress-fill",style:{width:`${a.progress}%`}})})]})]}),e.jsx("style",{children:`
        .agent-status-panel {
          background: rgba(30, 41, 59, 0.8);
          backdrop-filter: blur(12px);
          border-top: 1px solid rgba(255, 255, 255, 0.1);
          padding: 16px;
          z-index: 1000;
          animation: slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1);
          box-shadow: 0 -8px 32px rgba(0, 0, 0, 0.4);
        }

        @keyframes slideUp {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        .status-content {
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .status-icon {
          font-size: 32px;
          filter: drop-shadow(0 0 8px rgba(59, 130, 246, 0.5));
          animation: pulse 2s infinite cubic-bezier(0.4, 0, 0.6, 1);
        }

        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
            opacity: 1;
          }
          50% {
            transform: scale(1.1);
            opacity: 0.8;
          }
        }

        .status-info {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .status-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .agent-name {
          font-size: 14px;
          font-weight: 800;
          color: #ffffff;
          letter-spacing: 1px;
          text-transform: uppercase;
        }

        .status-badge {
          font-size: 10px;
          font-weight: 900;
          color: white;
          padding: 4px 10px;
          border-radius: 100px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }

        .status-message {
          font-size: 13px;
          color: #e2e8f0;
          line-height: 1.5;
          font-weight: 500;
        }

        .progress-bar {
          width: 100%;
          height: 6px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 100px;
          overflow: hidden;
          margin-top: 4px;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #3b82f6, #8b5cf6, #3b82f6);
          background-size: 200% 100%;
          border-radius: 100px;
          transition: width 0.5s cubic-bezier(0.4, 0, 0.2, 1);
          animation: shimmer 2s infinite linear;
        }

        @keyframes shimmer {
          0% { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
      `})]})},M="http://127.0.0.1:5001/w3bn3xt/us-central1",k={ui:{title:"UI Agent",icon:"🎨",desc:"Visuals & Branding",price:"0.005"},ux:{title:"UX Agent",icon:"🧠",desc:"Flow & Accessibility",price:"0.008"},dom:{title:"DOM Agent",icon:"🏗️",desc:"Structure & Perf",price:"0.003"},security:{title:"Security Agent",icon:"🛡️",desc:"Vulnerabilities",price:"0.012"}},me=({issue:a})=>{var c;const[r,s]=De.useState(!1);return e.jsxs("div",{className:`issue-card sev-${a.severity}`,onClick:()=>s(i=>!i),style:{cursor:"pointer"},children:[e.jsxs("div",{className:"issue-card-header",children:[e.jsx("span",{className:`sev-badge sev-${a.severity}`,children:(c=a.severity)==null?void 0:c.toUpperCase()}),e.jsx("span",{className:"issue-title",children:a.title}),e.jsx("span",{style:{marginLeft:"auto",fontSize:"10px",color:"var(--text-muted)"},children:r?"▲":"▼"})]}),r&&e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"issue-desc",children:a.description}),a.recommendation&&e.jsxs("div",{className:"issue-rec",children:["💡 ",a.recommendation]})]})]})},Je=()=>{var ce,de,pe;const[a,r]=o.useState(!0),[s,c]=o.useState(null),[i,p]=o.useState("0.000000"),[z,Y]=o.useState(0),[ue,he]=o.useState(!0),[U,q]=o.useState(!1),[A,be]=o.useState("dashboard"),[V,H]=o.useState([]),[x,X]=o.useState(null),[D,R]=o.useState([]),[J,Q]=o.useState(!1),[Z,E]=o.useState(null),[K,ee]=o.useState(!1),[W,te]=o.useState(""),[m,u]=o.useState("idle"),[ae,h]=o.useState(""),[se,we]=o.useState([]),[ye,re]=o.useState(!1),[_,y]=o.useState("none"),[g,ve]=o.useState(null),[v,$]=o.useState("idle"),[T,O]=o.useState(null),[f,F]=o.useState(null),[je,ne]=o.useState(!1),[b,ie]=o.useState(null),[Ne,ke]=o.useState(null),w=o.useCallback((t,n="info")=>{ie({message:t,type:n}),setTimeout(()=>ie(null),6e3)},[]),I=o.useCallback(async t=>{q(!0);try{const l=(await Ge(t)).find(d=>d.token.symbol==="USDC"||d.token.symbol.toLowerCase().includes("usdc"));p(l?parseFloat(l.amount).toFixed(6):"0.000000")}catch(n){console.error("Failed to fetch wallet balance:",n),p("0.000000")}finally{q(!1)}},[]),j=o.useCallback(async t=>{const n=await chrome.storage.local.get([`credits_${t}`,`audits_${t}`,`settlements_${t}`]);Y(n[`credits_${t}`]||0),H(n[`audits_${t}`]||[]);const l=n[`settlements_${t}`]||[];l.length>0&&R(l),await I(t);try{const d=await ge(t);R(d),await chrome.storage.local.set({[`settlements_${t}`]:d})}catch{}},[I]);o.useEffect(()=>{(async()=>{const d=await L();c(d),d&&await j(d),he(!1)})();const t=setInterval(async()=>{const d=await L();if(d&&A==="dashboard"){await I(d);try{const N=await ge(d);R(N),await chrome.storage.local.set({[`settlements_${d}`]:N})}catch{}}},1e4),n=d=>{if(d.circleWalletAddress){const N=d.circleWalletAddress.newValue||null;c(N),N&&j(N)}s&&(d[`audits_${s}`]||d[`credits_${s}`])&&j(s)},l=d=>{d.type==="AUDIT_COMPLETE"&&(s&&j(s),E(null)),d.type==="AUDIT_ERROR"&&(w(d.error,"error"),E(null)),d.type==="AGENT_STATUS"&&E(d.status)};return chrome.storage.onChanged.addListener(n),chrome.runtime.onMessage.addListener(l),()=>{chrome.storage.onChanged.removeListener(n),chrome.runtime.onMessage.removeListener(l),clearInterval(t)}},[j,A,s]);const Se=async()=>{Q(!0);try{const t=await xe();c(t),await j(t)}catch(t){console.error("Wallet creation error:",t),w("Failed to initialize Arc Wallet. Check your connection.","error")}finally{Q(!1)}},Ce=async()=>{await fe(),c(null),p("0.000000"),Y(0),H([])},ze=async()=>{ee(!0);try{await fe();const t=await xe();c(t),await j(t),w(`New wallet created: ${t}`,"success")}catch(t){console.error("New wallet creation error:",t),w("Failed to create new wallet. Check your connection.","error")}finally{ee(!1)}},oe=async t=>{try{$("bridging");const n=await L();if(!n)return;const d=await(await fetch(`${M}/${t==="Ethereum_Sepolia"?"bridgeFromEthereum":"bridgeFromSolana"}`,{method:"POST",headers:{"Content-Type":"application/json","X-Wallet-Address":n},body:JSON.stringify({amount:"1.0"})})).json();d.success?($("success"),w("Bridge transaction submitted!","success"),s&&await I(s)):($("error"),w(d.message||"Bridge failed","error"))}catch(n){$("error"),w(n.message||"Bridge failed","error")}},Ae=async()=>{try{const t=await L();if(!t)return;const l=await(await fetch(`${M}/getWalletBalance`,{method:"POST",headers:{"Content-Type":"application/json","X-Wallet-Address":t}})).json();ve(l)}catch(t){console.error("Failed to fetch cross-chain balances:",t)}};o.useEffect(()=>{_==="details"&&Ae()},[_]);const We=async()=>{y("import"),u("idle"),h(""),te(""),re(!0);try{const t=await Ve();we(t.wallets)}catch(t){console.error("Failed to load available wallets:",t)}finally{re(!1)}},_e=async()=>{var t;if(!W||!/^0x[a-fA-F0-9]{40}$/.test(W)){u("error"),h("Invalid wallet address format. Must be 0x followed by 40 hex characters.");return}u("verifying"),h("Verifying wallet address...");try{const n=await Ye(W);if(!n.valid||!n.exists){u("error"),h(n.message||"Wallet not found in your Circle account.");return}if(n.alreadyImported){u("error"),h("This wallet is already imported.");return}u("success"),h(`✅ Wallet verified! Blockchain: ${(t=n.wallet)==null?void 0:t.blockchain}`)}catch(n){u("error"),h(n.message||"Failed to verify wallet.")}},le=async t=>{const n=t||W;if(!n||!/^0x[a-fA-F0-9]{40}$/.test(n)){u("error"),h("Invalid wallet address format.");return}u("importing"),h("Importing wallet...");try{const l=await qe(n);u("success"),h(`✅ ${l.message}`),c(l.wallet.address),await j(l.wallet.address),setTimeout(()=>{y("none")},2e3)}catch(l){u("error"),h(l.message||"Failed to import wallet.")}},Te=()=>{s&&(navigator.clipboard.writeText(s),w("Wallet address copied to clipboard!","success"))},Be=o.useCallback(async t=>{if(s){O(t),F(null),ne(!0);try{const l=await(await fetch(`${M}/getAgentQuote?agent=${t}`,{headers:{"X-Wallet-Address":s}})).json();F(l)}catch{const n=parseFloat(k[t].price),l=parseFloat(i);F({agentType:t,priceUsdc:n,gasBuffer:.001,totalRequired:n+.001,userBalance:l,canProceed:l>=n+.001,needsBridge:!1})}finally{ne(!1)}}},[s,i]),Ue=o.useCallback(()=>{if(!T||!s)return;const t=T;O(null),F(null),chrome.tabs.query({active:!0,currentWindow:!0},n=>{var l;(l=n[0])!=null&&l.id&&(E({agentType:t,status:"analyzing",message:`Charging ${k[t].price} USDC → ${t.toUpperCase()} Agent…`,progress:5,timestamp:Date.now()}),chrome.runtime.sendMessage({type:"TRIGGER_AUDIT",auditType:t,url:n[0].url||"",walletAddress:s}))})},[T,s]),[B,Fe]=o.useState(!1),Ie=o.useCallback(()=>{chrome.tabs.query({active:!0,currentWindow:!0},async t=>{var n;if((n=t[0])!=null&&n.id)try{const l=await chrome.tabs.sendMessage(t[0].id,{type:"WAND_TOGGLE"});Fe((l==null?void 0:l.active)??!B)}catch{w("Wand is not available on this page. Navigate to a regular website first.","warning")}})},[B,w]);return a?e.jsx($e,{onComplete:()=>r(!1)}):ue?e.jsx("div",{className:"p-loading",children:e.jsxs("div",{className:"loading-inner",children:[e.jsxs("svg",{className:"gear-spin",viewBox:"0 0 64 64",width:"52",height:"52",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[e.jsx("path",{d:"M32 20a12 12 0 1 0 0 24 12 12 0 0 0 0-24zm0 20a8 8 0 1 1 0-16 8 8 0 0 1 0 16z",fill:"url(#gearGrad)"}),e.jsx("path",{d:"M54.6 27.2l-3.4-.6a20.2 20.2 0 0 0-1.6-3.8l2-2.8a2 2 0 0 0-.2-2.6l-4.8-4.8a2 2 0 0 0-2.6-.2l-2.8 2a20.2 20.2 0 0 0-3.8-1.6l-.6-3.4A2 2 0 0 0 35 8h-6a2 2 0 0 0-2 1.6l-.6 3.4a20.2 20.2 0 0 0-3.8 1.6l-2.8-2a2 2 0 0 0-2.6.2l-4.8 4.8a2 2 0 0 0-.2 2.6l2 2.8a20.2 20.2 0 0 0-1.6 3.8l-3.4.6A2 2 0 0 0 8 29v6a2 2 0 0 0 1.6 2l3.4.6a20.2 20.2 0 0 0 1.6 3.8l-2 2.8a2 2 0 0 0 .2 2.6l4.8 4.8a2 2 0 0 0 2.6.2l2.8-2a20.2 20.2 0 0 0 3.8 1.6l.6 3.4A2 2 0 0 0 29 56h6a2 2 0 0 0 2-1.6l.6-3.4a20.2 20.2 0 0 0 3.8-1.6l2.8 2a2 2 0 0 0 2.6-.2l4.8-4.8a2 2 0 0 0 .2-2.6l-2-2.8a20.2 20.2 0 0 0 1.6-3.8l3.4-.6A2 2 0 0 0 56 35v-6a2 2 0 0 0-1.4-1.8z",fill:"url(#gearGrad)",opacity:"0.85"}),e.jsx("defs",{children:e.jsxs("linearGradient",{id:"gearGrad",x1:"8",y1:"8",x2:"56",y2:"56",gradientUnits:"userSpaceOnUse",children:[e.jsx("stop",{stopColor:"#3b82f6"}),e.jsx("stop",{offset:"1",stopColor:"#8b5cf6"})]})})]}),e.jsx("span",{className:"loading-text",children:"Starting AudiBit..."}),e.jsx("span",{className:"loading-sub",children:"Connecting to Arc Testnet"})]})}):e.jsxs("div",{className:"app",children:[e.jsxs("header",{className:"header",children:[e.jsxs("div",{className:"brand",children:[e.jsx("div",{className:"logo-icon",children:e.jsxs("svg",{width:"24",height:"24",viewBox:"0 0 48 48",fill:"none",children:[e.jsx("rect",{width:"48",height:"48",rx:"10",fill:"url(#AzureGrad)"}),e.jsx("path",{d:"M24 12L36 34H12L24 12Z",fill:"white"}),e.jsx("defs",{children:e.jsxs("linearGradient",{id:"AzureGrad",x1:"0",y1:"0",x2:"48",y2:"48",children:[e.jsx("stop",{stopColor:"#3b82f6"}),e.jsx("stop",{offset:"1",stopColor:"#4338ca"})]})})]})}),e.jsxs("span",{className:"brand-name",children:["Audi",e.jsx("span",{className:"text-azure",children:"Bit"})]})]}),e.jsx("div",{className:"header-actions",children:s&&e.jsxs("div",{className:"arc-status",children:[e.jsx("span",{children:"Arc Testnet"}),e.jsx("div",{className:"status-dot pulse"})]})})]}),s?e.jsxs(e.Fragment,{children:[e.jsx("nav",{className:"tabs",children:["dashboard","history","payments"].map(t=>e.jsxs("button",{className:`tab-btn ${A===t?"tab-btn-active":""}`,onClick:()=>be(t),children:[e.jsx("span",{className:"tab-icon",children:t==="dashboard"?"📊":t==="history"?"📜":"💸"}),t==="dashboard"?"Overview":t==="history"?"Logs":"Settlements"]},t))}),e.jsxs("main",{className:`main ${Z?"main-with-status":""}`,children:[A==="dashboard"&&e.jsxs("div",{className:"dashboard",children:[e.jsxs("div",{className:"card-grid",children:[e.jsxs("div",{className:"card card-hero",children:[e.jsx("div",{className:"card-label",children:"Economic Activity"}),e.jsxs("div",{className:"card-value",children:[D.reduce((t,n)=>t+n.computeUnits,0)," ",e.jsx("span",{className:"unit",children:"CU"})]}),e.jsx("div",{className:"card-sub",children:"Compute Units consumed on Arc"})]}),e.jsxs("div",{className:"card",children:[e.jsxs("div",{className:"card-label",children:["USDC Balance",s&&e.jsx("button",{onClick:()=>I(s),disabled:U,style:{marginLeft:"8px",background:"none",border:"none",cursor:U?"not-allowed":"pointer",fontSize:"12px",opacity:U?.5:1},title:"Refresh balance",children:"🔄"})]}),e.jsx("div",{className:"card-value",children:U?e.jsx("span",{style:{fontSize:"14px",color:"var(--text-muted)"},children:"Loading..."}):e.jsxs(e.Fragment,{children:[parseFloat(i).toFixed(4)," ",e.jsx("span",{className:"unit",children:"USDC"})]})}),e.jsxs("div",{className:"card-sub",children:["Available for audits",s&&parseFloat(i)===0&&e.jsx("button",{onClick:()=>window.open(`https://faucet.circle.com?address=${s}`,"_blank"),style:{marginTop:"6px",padding:"4px 8px",background:"var(--azure)",color:"white",border:"none",borderRadius:"6px",fontSize:"10px",fontWeight:"600",cursor:"pointer",display:"block",width:"100%"},title:"Get free USDC from Circle faucet",children:"💰 Get USDC (Arc Testnet)"})]})]}),e.jsxs("div",{className:"card",children:[e.jsx("div",{className:"card-label",children:"Compute Credits"}),e.jsxs("div",{className:"card-value",children:[z," ",e.jsx("span",{className:"unit",children:"CU"})]}),e.jsx("div",{className:"card-sub",children:"Usage tracking credits"})]})]}),e.jsx("div",{className:"section-header",children:"AudiBit Agents"}),e.jsx("div",{className:"audit-grid",children:Object.entries(k).map(([t,n])=>e.jsxs("div",{className:"audit-card",onClick:()=>Be(t),children:[e.jsx("div",{className:`audit-icon icon-${t}`,children:n.icon}),e.jsxs("div",{className:"audit-info",children:[e.jsx("div",{className:"audit-title",children:n.title}),e.jsxs("div",{className:"audit-price",children:[n.price," USDC / scan"]})]}),e.jsx("div",{className:"agent-desc",children:n.desc})]},t))}),e.jsxs("div",{className:`wand-card ${B?"wand-active":""}`,onClick:Ie,children:[e.jsxs("div",{className:"wand-left",children:[e.jsxs("div",{className:"wand-icon-wrap",children:[e.jsx("span",{className:"wand-icon",children:"🪄"}),B&&e.jsx("span",{className:"wand-listening-ring"})]}),e.jsxs("div",{className:"wand-info",children:[e.jsxs("div",{className:"wand-title",children:["Wand",B&&e.jsx("span",{className:"wand-live-badge",children:"LIVE"})]}),e.jsx("div",{className:"wand-desc",children:B?"Listening — point at anything and speak":"Voice-first browser assistant · 0.002 USDC / query"})]})]}),e.jsxs("div",{className:"wand-shortcut",children:[e.jsx("kbd",{children:"Ctrl"}),e.jsx("span",{children:"+"}),e.jsx("kbd",{children:"Space"})]})]}),e.jsx("div",{className:"section-header",children:"Live Settlement Log"}),e.jsx(He,{logs:D.slice(0,5)})]}),A==="history"&&e.jsx("div",{className:"history-view",children:x?e.jsxs("div",{className:"issue-detail",children:[e.jsx("button",{className:"back-btn",onClick:()=>X(null),children:"← Back to Logs"}),e.jsxs("div",{className:"detail-header",children:[e.jsxs("span",{className:`badge badge-${x.type}`,children:[(ce=k[x.type])==null?void 0:ce.icon," ",x.type.toUpperCase()]}),e.jsx("span",{className:"record-date",children:new Date(x.timestamp).toLocaleDateString("en-GB")})]}),e.jsx("div",{className:"detail-url",title:x.url,children:x.url}),e.jsxs("div",{className:"detail-meta",children:[e.jsxs("span",{className:x.issuesCount>0?"text-danger":"text-success",children:[x.issuesCount," Issue",x.issuesCount!==1?"s":""," Found"]}),x.cost&&e.jsxs("span",{className:"text-azure",children:[x.cost," USDC"]})]}),!x.issues||x.issues.length===0?e.jsx("div",{className:"empty-state",style:{marginTop:"20px"},children:"✅ No issues found on this page."}):e.jsx("div",{className:"issue-list",children:x.agentResults&&x.agentResults.length>0?x.agentResults.map((t,n)=>{var l;return e.jsxs("div",{className:"agent-section",children:[e.jsxs("div",{className:"agent-section-header",children:[e.jsxs("span",{className:`badge badge-${t.agentType}`,children:[(l=k[t.agentType])==null?void 0:l.icon," ",t.agentType.toUpperCase()]}),e.jsxs("span",{className:"agent-section-meta",children:[t.issues.length," issue",t.issues.length!==1?"s":"",t.cost?` · ${t.cost} USDC`:""]})]}),t.issues.length===0?e.jsx("div",{className:"agent-no-issues",children:"✅ No issues"}):t.issues.map((d,N)=>e.jsx(me,{issue:d},N))]},n)}):x.issues.map((t,n)=>e.jsx(me,{issue:t},n))})]}):e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"section-header",children:"Audit Records"}),V.length===0?e.jsx("div",{className:"empty-state",children:"No audits recorded yet."}):e.jsx("div",{className:"record-list",children:V.map(t=>{var n;return e.jsxs("div",{className:"record-card",onClick:()=>X(t),style:{cursor:"pointer"},children:[e.jsxs("div",{className:"record-header",children:[e.jsxs("span",{className:`badge badge-${t.type}`,children:[(n=k[t.type])==null?void 0:n.icon," ",t.type.toUpperCase()]}),e.jsx("span",{className:"record-date",children:new Date(t.timestamp).toLocaleDateString("en-GB")})]}),e.jsx("div",{className:"record-url",children:t.url}),e.jsxs("div",{className:"record-footer",children:[e.jsxs("span",{className:t.issuesCount>0?"text-danger":"text-success",children:[t.issuesCount," Issues Found"]}),e.jsxs("span",{className:"record-chevron",children:[t.cost?`${t.cost} USDC`:""," ›"]})]})]},t.id)})})]})}),A==="payments"&&e.jsxs("div",{className:"payments-view",children:[e.jsx("div",{className:"section-header",children:"Arc L1 Settlement History"}),D.length===0?e.jsx("div",{className:"empty-state",children:"No settlements on Arc yet."}):e.jsx("div",{className:"settlement-list",children:D.map(t=>{var l;const n=Ne===t.id;return e.jsxs("div",{className:"settlement-card",children:[e.jsxs("div",{className:"settlement-row",onClick:()=>ke(n?null:t.id),children:[e.jsxs("div",{className:"settlement-left",children:[e.jsx("div",{className:"settlement-desc",children:t.description}),e.jsxs("div",{className:"settlement-tx",children:["TX: ",(l=t.transactionId)==null?void 0:l.slice(0,14),"…"]})]}),e.jsxs("div",{className:"settlement-right",children:[e.jsxs("div",{className:"settlement-amount",children:[(parseFloat(t.amount)||0).toFixed(4)," USDC"]}),e.jsxs("div",{className:"settlement-cu",children:[t.computeUnits," CU"]})]}),e.jsx("span",{className:"expand-chevron",children:n?"▲":"▼"})]}),n&&e.jsxs("div",{className:"settlement-detail",children:[e.jsxs("div",{className:"sdet-row",children:[e.jsx("span",{className:"sdet-label",children:"Circle TX ID"}),e.jsx("span",{className:"sdet-val mono",children:t.transactionId})]}),t.txHash&&e.jsxs("div",{className:"sdet-row",children:[e.jsx("span",{className:"sdet-label",children:"On-chain Hash"}),e.jsx("span",{className:"sdet-val mono",children:t.txHash})]}),e.jsxs("div",{className:"sdet-row",children:[e.jsx("span",{className:"sdet-label",children:"Amount"}),e.jsxs("span",{className:"sdet-val",children:[t.amount," USDC"]})]}),e.jsxs("div",{className:"sdet-row",children:[e.jsx("span",{className:"sdet-label",children:"Compute Units"}),e.jsxs("span",{className:"sdet-val",children:[t.computeUnits," CU"]})]}),e.jsxs("div",{className:"sdet-row",children:[e.jsx("span",{className:"sdet-label",children:"Status"}),e.jsx("span",{className:`sdet-val status-${t.status}`,children:t.status})]}),e.jsxs("div",{className:"sdet-row",children:[e.jsx("span",{className:"sdet-label",children:"Date"}),e.jsx("span",{className:"sdet-val",children:new Date(t.createdAt).toLocaleString()})]}),t.txHash?e.jsx("a",{href:`https://testnet.arcscan.app/tx/${t.txHash}`,target:"_blank",rel:"noreferrer",className:"explorer-link",children:"View on Arc Testnet Explorer ↗"}):e.jsx("span",{className:"explorer-pending",children:"⏳ On-chain hash pending confirmation"})]})]},t.id)})})]})]}),e.jsx(Xe,{status:Z}),T&&e.jsx("div",{style:{position:"fixed",inset:0,background:"rgba(0,0,0,0.7)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:2147483647,padding:"20px"},children:e.jsxs("div",{style:{background:"#0f172a",borderRadius:"20px",padding:"28px",width:"100%",maxWidth:"360px",border:"1px solid rgba(59,130,246,0.3)",boxShadow:"0 25px 60px rgba(0,0,0,0.6)",fontFamily:'-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif'},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"12px",marginBottom:"20px"},children:[e.jsx("span",{style:{fontSize:"28px"},children:(de=k[T])==null?void 0:de.icon}),e.jsxs("div",{children:[e.jsx("div",{style:{color:"white",fontWeight:700,fontSize:"16px"},children:(pe=k[T])==null?void 0:pe.title}),e.jsx("div",{style:{color:"rgba(255,255,255,0.5)",fontSize:"12px"},children:"Arc Testnet · Circle Nanopayment"})]})]}),je?e.jsx("div",{style:{textAlign:"center",padding:"20px",color:"rgba(255,255,255,0.6)"},children:"Fetching quote…"}):f?e.jsxs(e.Fragment,{children:[e.jsxs("div",{style:{background:"rgba(255,255,255,0.05)",borderRadius:"12px",padding:"16px",marginBottom:"16px"},children:[e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",marginBottom:"8px"},children:[e.jsx("span",{style:{color:"rgba(255,255,255,0.6)",fontSize:"13px"},children:"Agent fee"}),e.jsxs("span",{style:{color:"white",fontWeight:600,fontSize:"13px"},children:[f.priceUsdc.toFixed(6)," USDC"]})]}),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",marginBottom:"12px"},children:[e.jsx("span",{style:{color:"rgba(255,255,255,0.6)",fontSize:"13px"},children:"Gas buffer"}),e.jsxs("span",{style:{color:"rgba(255,255,255,0.6)",fontSize:"13px"},children:[f.gasBuffer.toFixed(6)," USDC"]})]}),e.jsxs("div",{style:{borderTop:"1px solid rgba(255,255,255,0.1)",paddingTop:"10px",display:"flex",justifyContent:"space-between"},children:[e.jsx("span",{style:{color:"white",fontWeight:700,fontSize:"14px"},children:"Total"}),e.jsxs("span",{style:{color:"#3b82f6",fontWeight:700,fontSize:"14px"},children:[f.totalRequired.toFixed(6)," USDC"]})]})]}),e.jsxs("div",{style:{display:"flex",justifyContent:"space-between",marginBottom:"16px",fontSize:"12px"},children:[e.jsx("span",{style:{color:"rgba(255,255,255,0.5)"},children:"Your balance"}),e.jsxs("span",{style:{color:f.canProceed?"#10b981":"#ef4444",fontWeight:600},children:[f.userBalance.toFixed(6)," USDC",f.canProceed?" ✓":" ✗"]})]}),f.needsBridge&&e.jsxs("div",{style:{background:"rgba(245,158,11,0.15)",border:"1px solid rgba(245,158,11,0.4)",borderRadius:"10px",padding:"12px",marginBottom:"16px",fontSize:"12px",color:"#fbbf24"},children:["⚡ Your wallet is on ",e.jsx("strong",{children:f.sourceChain}),". USDC will be bridged to Arc Testnet via Circle CCTP before payment."]}),!f.canProceed&&e.jsxs("div",{style:{background:"rgba(239,68,68,0.15)",border:"1px solid rgba(239,68,68,0.4)",borderRadius:"10px",padding:"12px",marginBottom:"16px",fontSize:"12px",color:"#fca5a5"},children:["Insufficient balance. Need"," ",e.jsxs("strong",{children:[(f.totalRequired-f.userBalance).toFixed(6)," more USDC"]}),"."," ",e.jsx("a",{href:`https://faucet.circle.com?address=${s}`,target:"_blank",rel:"noreferrer",style:{color:"#60a5fa",textDecoration:"underline"},children:"Get USDC →"})]}),e.jsxs("div",{style:{display:"flex",gap:"10px"},children:[e.jsx("button",{onClick:()=>{O(null),F(null)},style:{flex:1,padding:"12px",background:"rgba(255,255,255,0.08)",border:"1px solid rgba(255,255,255,0.15)",borderRadius:"10px",color:"white",cursor:"pointer",fontSize:"14px",fontWeight:600},children:"Cancel"}),e.jsx("button",{onClick:Ue,disabled:!f.canProceed,style:{flex:2,padding:"12px",background:f.canProceed?"linear-gradient(135deg,#3b82f6,#8b5cf6)":"rgba(255,255,255,0.1)",border:"none",borderRadius:"10px",color:f.canProceed?"white":"rgba(255,255,255,0.3)",cursor:f.canProceed?"pointer":"not-allowed",fontSize:"14px",fontWeight:700},children:f.canProceed?`Pay ${f.priceUsdc.toFixed(4)} USDC & Run`:"Insufficient Balance"})]})]}):null]})}),b&&e.jsx("div",{style:{position:"fixed",bottom:"80px",left:"50%",transform:"translateX(-50%)",background:b.type==="error"?"#ef4444":b.type==="success"?"#10b981":b.type==="warning"?"#f59e0b":"#3b82f6",color:"white",padding:"12px 20px",borderRadius:"12px",fontSize:"13px",fontWeight:600,zIndex:2147483646,maxWidth:"360px",textAlign:"center",boxShadow:"0 8px 24px rgba(0,0,0,0.4)"},children:b.message}),e.jsxs("footer",{className:"footer",children:[e.jsxs("div",{className:"wallet-info",onClick:()=>y("details"),style:{cursor:"pointer"},children:[e.jsx("span",{className:"wallet-dot"}),e.jsxs("span",{className:"wallet-addr",children:[s.slice(0,10),"...",s.slice(-6)]}),e.jsx("span",{className:"wallet-expand",children:_==="details"?"▲":"▼"})]}),e.jsx("button",{className:"logout-btn",onClick:Ce,children:"Disconnect"})]}),b&&e.jsxs("div",{className:`notification notification-${b.type}`,children:[b.type==="success"?"✅":b.type==="error"?"❌":"ℹ️",b.message]}),_==="import"&&e.jsx("div",{className:"wallet-modal",children:e.jsxs("div",{className:"modal-content",children:[e.jsxs("div",{className:"modal-header",children:[e.jsx("h3",{children:"Import Existing Wallet"}),e.jsx("button",{className:"close-btn",onClick:()=>y("none"),children:"×"})]}),e.jsxs("div",{className:"modal-body",children:[e.jsxs("div",{className:"import-section",children:[e.jsx("label",{children:"Enter Wallet Address"}),e.jsx("input",{type:"text",className:"wallet-input",placeholder:"0x...",value:W,onChange:t=>te(t.target.value),disabled:m==="verifying"||m==="importing"}),e.jsxs("div",{className:"import-actions",children:[e.jsx("button",{className:"btn btn-secondary",onClick:_e,disabled:!W||m==="verifying"||m==="importing",children:m==="verifying"?"Verifying...":"Verify"}),e.jsx("button",{className:"btn btn-primary",onClick:()=>le(),disabled:m!=="success"&&m!=="idle",children:m==="importing"?"Importing...":"Import"})]}),ae&&e.jsx("div",{className:`import-message ${m==="error"?"error":m==="success"?"success":"info"}`,children:ae})]}),e.jsx("div",{className:"divider",children:e.jsx("span",{children:"OR"})}),e.jsxs("div",{className:"import-section",children:[e.jsx("label",{children:"Select from Your Circle Wallets"}),ye?e.jsx("div",{className:"loading-wallets",children:"Loading wallets..."}):se.length===0?e.jsx("div",{className:"empty-wallets",children:"No Arc wallets found in your Circle account."}):e.jsx("div",{className:"wallet-list",children:se.map(t=>e.jsxs("div",{className:"wallet-list-item",children:[e.jsxs("div",{className:"wallet-list-info",children:[e.jsxs("div",{className:"wallet-list-address",children:[t.address.slice(0,10),"...",t.address.slice(-8)]}),e.jsx("div",{className:"wallet-list-blockchain",children:t.blockchain})]}),t.imported?e.jsx("span",{className:"wallet-imported-badge",children:"✓ Imported"}):e.jsx("button",{className:"btn btn-sm btn-primary",onClick:()=>le(t.address),disabled:m==="importing",children:"Import"})]},t.address))})]}),e.jsxs("div",{className:"import-info",children:[e.jsxs("p",{children:["💡 ",e.jsx("strong",{children:"Bring Your Own Wallet (BYOW)"})]}),e.jsx("p",{children:"Import an existing Circle wallet created with the same API credentials. The wallet must be on Arc Testnet or Arc Mainnet."})]})]})]})}),_==="details"&&e.jsx("div",{className:"wallet-modal",children:e.jsxs("div",{className:"modal-content",children:[e.jsxs("div",{className:"modal-header",children:[e.jsx("h3",{children:"Wallet Details"}),e.jsx("button",{className:"close-btn",onClick:()=>y("none"),children:"×"})]}),e.jsxs("div",{className:"modal-body",children:[e.jsxs("div",{className:"wallet-detail-section",children:[e.jsx("label",{children:"Wallet Address"}),e.jsxs("div",{className:"wallet-address-display",children:[e.jsx("code",{children:s}),e.jsx("button",{className:"copy-btn",onClick:Te,title:"Copy address",children:"📋"})]})]}),e.jsxs("div",{className:"wallet-detail-section",children:[e.jsx("label",{children:"Network"}),e.jsxs("div",{className:"network-badge",children:[e.jsx("span",{className:"status-dot pulse"}),"Arc Testnet (L1)"]})]}),e.jsx("div",{className:"section-header",children:"Cross-Chain Liquidity"}),e.jsxs("div",{className:"bridge-info-grid",style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"8px",marginBottom:"16px"},children:[e.jsxs("div",{className:"bridge-card",style:{padding:"8px",border:"1px solid var(--border)",borderRadius:"8px"},children:[e.jsx("div",{className:"bridge-card-label",style:{fontSize:"10px",color:"var(--text-muted)"},children:"Ethereum (Sepolia)"}),e.jsxs("div",{className:"bridge-card-value",style:{fontWeight:"bold",fontSize:"12px"},children:[(g==null?void 0:g.ethereumBalance)||"0.00"," ",e.jsx("span",{className:"unit",children:"USDC"})]}),e.jsx("button",{className:"btn btn-sm btn-secondary",onClick:()=>oe("Ethereum_Sepolia"),disabled:v==="bridging"||parseFloat((g==null?void 0:g.ethereumBalance)||"0")===0,style:{marginTop:"4px",fontSize:"10px",width:"100%"},children:"Bridge"})]}),e.jsxs("div",{className:"bridge-card",style:{padding:"8px",border:"1px solid var(--border)",borderRadius:"8px"},children:[e.jsx("div",{className:"bridge-card-label",style:{fontSize:"10px",color:"var(--text-muted)"},children:"Solana (Devnet)"}),e.jsxs("div",{className:"bridge-card-value",style:{fontWeight:"bold",fontSize:"12px"},children:[(g==null?void 0:g.solanaBalance)||"0.00"," ",e.jsx("span",{className:"unit",children:"USDC"})]}),e.jsx("button",{className:"btn btn-sm btn-secondary",onClick:()=>oe("Solana_Devnet"),disabled:v==="bridging"||parseFloat((g==null?void 0:g.solanaBalance)||"0")===0,style:{marginTop:"4px",fontSize:"10px",width:"100%"},children:"Bridge"})]})]}),v!=="idle"&&e.jsxs("div",{className:`bridge-status-banner ${v}`,style:{fontSize:"11px",marginBottom:"10px",padding:"4px"},children:[v==="checking"&&"🔍 Checking cross-chain funds...",v==="bridging"&&"🌉 Bridging in progress (10-30s)...",v==="success"&&"✅ Bridge successful!",v==="error"&&"❌ Bridge failed."]}),e.jsxs("div",{className:"wallet-detail-section",children:[e.jsx("label",{children:"Balance"}),e.jsx("div",{className:"balance-display",children:U?"Loading...":`${parseFloat(i).toFixed(6)} USDC`})]}),e.jsxs("div",{className:"wallet-actions",children:[e.jsx("button",{className:"btn btn-secondary btn-block",onClick:()=>y("confirm_new_wallet"),disabled:K,children:K?"Creating...":"🔄 Create New Wallet"}),e.jsx("button",{className:"btn btn-secondary btn-block",onClick:()=>y("import"),children:"📥 Import Existing Wallet"}),e.jsx("p",{className:"wallet-warning",children:"⚠️ Managed by Circle Arc API."})]})]})]})}),_==="confirm_new_wallet"&&e.jsx("div",{className:"wallet-modal",children:e.jsxs("div",{className:"modal-content",children:[e.jsxs("div",{className:"modal-header",children:[e.jsx("h3",{children:"Create New Wallet?"}),e.jsx("button",{className:"close-btn",onClick:()=>y("details"),children:"×"})]}),e.jsxs("div",{className:"modal-body",children:[e.jsx("p",{className:"subtitle",children:"This will disconnect your current wallet. Any funds in the current wallet will remain on the Arc blockchain, but you will need its address to access it later."}),e.jsxs("div",{className:"wallet-actions",children:[e.jsx("button",{className:"btn btn-primary btn-block",onClick:ze,children:"Confirm & Create"}),e.jsx("button",{className:"btn btn-secondary btn-block",onClick:()=>y("details"),children:"Cancel"})]})]})]})})]}):e.jsxs("div",{className:"connect-screen",children:[e.jsx("div",{className:"hero-asset",children:e.jsxs("div",{className:"floating-card",children:[e.jsx("div",{className:"card-logo",children:"Arc"}),e.jsxs("div",{className:"card-number",children:["•••• •••• •••• ",Math.floor(Math.random()*9e3)+1e3]})]})}),e.jsx("h2",{className:"title",children:"Professional Web Audits"}),e.jsx("p",{className:"subtitle",children:"Instant AI analysis with real-time USDC settlement on the Arc L1 blockchain."}),e.jsx("button",{className:"btn btn-primary btn-lg",onClick:Se,disabled:J,children:J?"Creating Wallet...":"Connect Arc Wallet"}),e.jsx("button",{className:"btn btn-secondary btn-lg",onClick:We,style:{marginTop:"12px"},children:"Import Existing Wallet"}),e.jsx("div",{className:"trust-badges",children:e.jsx("span",{children:"Powered by Circle Nanopayments"})})]}),e.jsx("style",{children:`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        
        :root {
          --primary: #3b82f6;
          --primary-dark: #2563eb;
          --bg: #f8fafc;
          --surface: #ffffff;
          --border: #e2e8f0;
          --text-main: #0f172a;
          --text-muted: #64748b;
          --azure: #3b82f6;
          --indigo: #4338ca;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        .app {
          width: 420px; height: 600px;
          background: var(--bg);
          color: var(--text-main);
          font-family: 'Inter', -apple-system, sans-serif;
          display: flex; flex-direction: column;
          overflow: hidden;
        }

        /* Header */
        .header {
          padding: 16px; background: var(--surface);
          border-bottom: 1px solid var(--border);
          display: flex; justify-content: space-between; align-items: center;
        }
        .brand { display: flex; align-items: center; gap: 10px; }
        .brand-name { font-size: 18px; font-weight: 800; letter-spacing: -0.5px; }
        .text-azure { color: var(--azure); }
        .arc-status {
          background: #f1f5f9; padding: 4px 10px; border-radius: 100px;
          font-size: 10px; font-weight: 700; color: var(--text-muted);
          display: flex; align-items: center; gap: 6px; text-transform: uppercase;
        }
        .status-dot { width: 6px; height: 6px; background: #22c55e; border-radius: 50%; }
        .pulse { animation: pulse 2s infinite; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.4; } 100% { opacity: 1; } }

        /* Connect Screen */
        .connect-screen {
          flex: 1; padding: 40px 30px; display: flex; flex-direction: column; align-items: center; text-align: center;
        }
        .hero-asset { margin-bottom: 30px; }
        .floating-card {
           width: 200px; height: 120px;
           background: linear-gradient(135deg, #3b82f6, #4338ca);
           border-radius: 16px; padding: 20px; color: white;
           box-shadow: 0 20px 40px rgba(59, 130, 246, 0.3);
           display: flex; flex-direction: column; justify-content: space-between;
           animation: float 4s ease-in-out infinite;
        }
        @keyframes float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
        .card-logo { font-weight: 900; font-style: italic; opacity: 0.8; }
        .card-number { font-family: monospace; font-size: 14px; opacity: 0.9; }
        .title { font-size: 22px; font-weight: 800; margin-bottom: 12px; }
        .subtitle { font-size: 13px; color: var(--text-muted); line-height: 1.6; margin-bottom: 30px; }
        .trust-badges { margin-top: auto; font-size: 11px; color: var(--text-muted); font-weight: 600; opacity: 0.6; }

        /* Dashboard */
        .tabs { display: flex; background: var(--surface); border-bottom: 1px solid var(--border); padding: 0 8px; gap: 4px; }
        .tab-btn {
          flex: 1; padding: 12px 8px; background: none; border: none;
          font-size: 11px; font-weight: 700; color: var(--text-muted);
          cursor: pointer; transition: all 0.2s;
          display: flex; flex-direction: column; align-items: center; gap: 4px;
          border-bottom: 3px solid transparent;
        }
        .tab-icon { font-size: 16px; margin-bottom: 2px; transition: transform 0.2s; }
        .tab-btn:hover .tab-icon { transform: translateY(-2px); }
        .tab-btn-active { color: var(--azure); border-bottom-color: var(--azure); }
        .tab-btn-active .tab-icon { transform: scale(1.1); }
        
        .main { flex: 1; padding: 16px; overflow-y: auto; transition: padding 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        .main-with-status { padding-bottom: 100px; }
        
        .card-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
        .card {
           background: var(--surface); border: 1px solid var(--border);
           border-radius: 12px; padding: 14px; display: flex; flex-direction: column;
        }
        .card-hero { grid-column: span 2; border-left: 4px solid var(--azure); }
        .card-label { font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; display: flex; align-items: center; }
        .card-value { font-size: 24px; font-weight: 800; color: var(--text-main); }
        .unit { font-size: 12px; font-weight: 500; color: var(--text-muted); }
        .card-sub { font-size: 11px; color: var(--text-muted); margin-top: 4px; }

        .section-header { font-size: 12px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; margin-bottom: 10px; margin-top: 20px; }
        
        .audit-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .audit-card {
           background: var(--surface); border: 1px solid var(--border);
           border-radius: 12px; padding: 12px; display: flex; flex-direction: column; align-items: center; gap: 8px;
           cursor: pointer; transition: all 0.2s; text-align: center;
        }
        .audit-card:hover { border-color: var(--azure); transform: translateY(-4px) scale(1.02); box-shadow: 0 12px 24px rgba(59, 130, 246, 0.15); }
        .audit-icon { font-size: 24px; width: 48px; height: 48px; background: #f1f5f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.3s; }
        .audit-card:hover .audit-icon { transform: rotate(10deg) scale(1.1); }
        .icon-ui { color: #3b82f6; background: #eff6ff; }
        .icon-ux { color: #8b5cf6; background: #f5f3ff; }
        .icon-dom { color: #10b981; background: #ecfdf5; }
        .icon-security { color: #ef4444; background: #fef2f2; }
        .audit-title { font-size: 13px; font-weight: 700; color: var(--text-main); }
        .audit-price { font-size: 10px; color: var(--azure); font-weight: 600; }
        .agent-desc { font-size: 10px; color: var(--text-muted); }

        /* Wand card */
        .wand-card {
          margin-top: 10px;
          background: var(--surface); border: 1px solid var(--border);
          border-radius: 12px; padding: 14px 16px;
          display: flex; align-items: center; justify-content: space-between;
          cursor: pointer; transition: border-color 0.2s, box-shadow 0.2s;
        }
        .wand-card:hover { border-color: #8b5cf6; box-shadow: 0 4px 14px rgba(139,92,246,0.12); }
        .wand-card.wand-active {
          border-color: #8b5cf6;
          background: linear-gradient(135deg, rgba(139,92,246,0.06), rgba(59,130,246,0.06));
          box-shadow: 0 0 0 2px rgba(139,92,246,0.25);
        }
        .wand-left { display: flex; align-items: center; gap: 12px; flex: 1; min-width: 0; }
        .wand-icon-wrap { position: relative; flex-shrink: 0; }
        .wand-icon { font-size: 26px; display: block; }
        .wand-listening-ring {
          position: absolute; inset: -5px; border-radius: 50%;
          border: 2px solid #8b5cf6;
          animation: wand-ring-pulse 1.2s ease-in-out infinite;
        }
        @keyframes wand-ring-pulse {
          0%, 100% { transform: scale(1); opacity: 0.8; }
          50%       { transform: scale(1.25); opacity: 0.3; }
        }
        .wand-info { min-width: 0; }
        .wand-title {
          font-size: 14px; font-weight: 700; color: var(--text-main);
          display: flex; align-items: center; gap: 6px;
        }
        .wand-live-badge {
          font-size: 9px; font-weight: 800; letter-spacing: 0.5px;
          background: #8b5cf6; color: white;
          padding: 2px 6px; border-radius: 4px;
          animation: wand-badge-blink 1.4s ease-in-out infinite;
        }
        @keyframes wand-badge-blink {
          0%, 100% { opacity: 1; } 50% { opacity: 0.5; }
        }
        .wand-desc { font-size: 10px; color: var(--text-muted); margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .wand-shortcut {
          display: flex; align-items: center; gap: 3px;
          flex-shrink: 0; margin-left: 10px;
        }
        .wand-shortcut kbd {
          background: #f1f5f9; border: 1px solid #cbd5e1;
          border-radius: 4px; padding: 2px 5px;
          font-size: 9px; font-weight: 700; color: var(--text-muted);
          font-family: monospace;
        }
        .wand-shortcut span { font-size: 9px; color: var(--text-muted); }

        /* Records */
        .record-list { display: flex; flex-direction: column; gap: 10px; }
        .record-card {
          background: var(--surface); border: 1px solid var(--border);
          border-radius: 12px; padding: 14px;
          transition: border-color 0.15s, box-shadow 0.15s;
        }
        .record-card:hover { border-color: var(--azure); box-shadow: 0 2px 12px rgba(59,130,246,0.12); }
        .record-header { display: flex; justify-content: space-between; margin-bottom: 8px; align-items: center; }
        .record-url { font-size: 12px; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 8px; }
        .record-footer { display: flex; justify-content: space-between; font-size: 12px; font-weight: 700; align-items: center; }
        .record-chevron { color: var(--text-muted); font-size: 13px; }
        .badge { font-size: 9px; font-weight: 800; padding: 3px 8px; border-radius: 6px; text-transform: uppercase; display: inline-flex; align-items: center; gap: 4px; }
        .badge-ui { background: #eff6ff; color: #1d4ed8; }
        .badge-ux { background: #f5f3ff; color: #6d28d9; }
        .badge-dom { background: #ecfdf5; color: #065f46; }
        .badge-security { background: #fee2e2; color: #b91c1c; }
        .badge-uiux { background: #e0f2fe; color: #0369a1; }
        .text-danger { color: #ef4444; }
        .text-success { color: #10b981; }

        /* Issue Detail Panel */
        .issue-detail { display: flex; flex-direction: column; gap: 12px; }
        .back-btn {
          background: none; border: none; color: var(--azure); font-size: 13px;
          font-weight: 600; cursor: pointer; padding: 0; text-align: left;
          display: flex; align-items: center; gap: 4px;
        }
        .back-btn:hover { text-decoration: underline; }
        .detail-header { display: flex; justify-content: space-between; align-items: center; }
        .detail-url {
          font-size: 11px; color: var(--text-muted); word-break: break-all;
          background: var(--bg); padding: 8px 10px; border-radius: 8px;
          border: 1px solid var(--border);
        }
        .detail-meta { display: flex; justify-content: space-between; font-size: 12px; font-weight: 700; }
        .issue-list { display: flex; flex-direction: column; gap: 10px; }
        .issue-card {
          background: var(--surface); border-radius: 10px; padding: 12px;
          border-left: 3px solid var(--border);
        }
        .issue-card.sev-critical { border-left-color: #ef4444; }
        .issue-card.sev-high     { border-left-color: #f97316; }
        .issue-card.sev-medium   { border-left-color: #f59e0b; }
        .issue-card.sev-low      { border-left-color: #3b82f6; }
        .issue-card.sev-info     { border-left-color: #10b981; }
        .issue-card-header { display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px; }
        .sev-badge {
          font-size: 9px; font-weight: 800; padding: 2px 6px; border-radius: 4px;
          text-transform: uppercase; white-space: nowrap; flex-shrink: 0;
        }
        .sev-badge.sev-critical { background: #fee2e2; color: #b91c1c; }
        .sev-badge.sev-high     { background: #ffedd5; color: #c2410c; }
        .sev-badge.sev-medium   { background: #fef3c7; color: #92400e; }
        .sev-badge.sev-low      { background: #eff6ff; color: #1d4ed8; }
        .sev-badge.sev-info     { background: #ecfdf5; color: #065f46; }
        .issue-title { font-size: 13px; font-weight: 700; color: var(--text-main); line-height: 1.4; }
        .issue-desc { font-size: 12px; color: var(--text-muted); line-height: 1.6; margin: 0 0 6px; }
        .issue-rec {
          font-size: 11px; color: #065f46; background: #ecfdf5;
          border-radius: 6px; padding: 6px 10px; line-height: 1.5;
        }

        /* Agent section grouping in detail view */
        .agent-section { margin-bottom: 14px; }
        .agent-section-header {
          display: flex; align-items: center; justify-content: space-between;
          margin-bottom: 8px; padding-bottom: 6px;
          border-bottom: 1px solid var(--border);
        }
        .agent-section-meta { font-size: 11px; color: var(--text-muted); font-weight: 600; }
        .agent-no-issues { font-size: 12px; color: #10b981; padding: 6px 0; }

        /* Settlements */
        .settlement-list { display: flex; flex-direction: column; gap: 8px; }
        .settlement-card {
          background: var(--surface); border: 1px solid var(--border);
          border-radius: 12px; overflow: hidden;
        }
        .settlement-row {
          display: flex; align-items: center; gap: 10px;
          padding: 12px 14px; cursor: pointer;
          transition: background 0.15s;
        }
        .settlement-row:hover { background: #f8fafc; }
        .settlement-left { flex: 1; min-width: 0; }
        .settlement-desc { font-size: 13px; font-weight: 600; color: var(--text-main); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .settlement-tx { font-size: 11px; color: var(--text-muted); font-family: monospace; margin-top: 2px; }
        .settlement-right { text-align: right; flex-shrink: 0; }
        .settlement-amount { font-size: 13px; font-weight: 700; color: var(--azure); }
        .settlement-cu { font-size: 10px; color: var(--text-muted); background: #f1f5f9; padding: 1px 6px; border-radius: 4px; margin-top: 2px; display: inline-block; }
        .expand-chevron { font-size: 10px; color: var(--text-muted); flex-shrink: 0; }
        .settlement-detail {
          border-top: 1px solid var(--border); padding: 12px 14px;
          background: #f8fafc; display: flex; flex-direction: column; gap: 8px;
        }
        .sdet-row { display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; font-size: 12px; }
        .sdet-label { color: var(--text-muted); font-weight: 600; flex-shrink: 0; }
        .sdet-val { color: var(--text-main); text-align: right; word-break: break-all; }
        .sdet-val.mono { font-family: monospace; font-size: 10px; }
        .sdet-val.status-confirmed, .sdet-val.status-completed { color: #10b981; font-weight: 700; }
        .sdet-val.status-pending { color: #f59e0b; font-weight: 700; }
        .sdet-val.status-failed { color: #ef4444; font-weight: 700; }
        .explorer-link {
          font-size: 11px; color: var(--azure); text-decoration: none;
          font-weight: 600; margin-top: 4px;
        }
        .explorer-link:hover { text-decoration: underline; }
        .explorer-pending {
          font-size: 11px; color: var(--text-muted); font-style: italic;
          margin-top: 4px;
        }

        /* Footer */
        .footer {
          padding: 12px 16px; background: var(--surface); border-top: 1px solid var(--border);
          display: flex; justify-content: space-between; align-items: center;
        }
        .wallet-info { display: flex; align-items: center; gap: 8px; }
        .wallet-dot { width: 6px; height: 6px; background: #22c55e; border-radius: 50%; }
        .wallet-addr { font-family: monospace; font-size: 11px; color: var(--text-muted); }
        .wallet-expand { font-size: 10px; color: var(--text-muted); margin-left: 4px; }
        .logout-btn { background: none; border: none; font-size: 11px; font-weight: 600; color: #ef4444; cursor: pointer; }

        /* Wallet Modal */
        .wallet-modal {
          position: absolute; top: 0; left: 0; right: 0; bottom: 0;
          background: rgba(0, 0, 0, 0.5); backdrop-filter: blur(4px);
          display: flex; align-items: flex-end; z-index: 1000;
          animation: fadeIn 0.2s;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        .modal-content {
          width: 100%; background: var(--surface);
          border-radius: 16px 16px 0 0; padding: 20px;
          animation: slideUp 0.3s;
        }
        @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
        .modal-header {
          display: flex; justify-content: space-between; align-items: center;
          margin-bottom: 20px;
        }
        .modal-header h3 { font-size: 18px; font-weight: 700; }
        .close-btn {
          background: none; border: none; font-size: 28px;
          color: var(--text-muted); cursor: pointer; line-height: 1;
        }
        .modal-body { display: flex; flex-direction: column; gap: 16px; }
        .wallet-detail-section label {
          display: block; font-size: 11px; font-weight: 700;
          color: var(--text-muted); text-transform: uppercase;
          margin-bottom: 8px; letter-spacing: 0.5px;
        }
        .wallet-address-display {
          display: flex; align-items: center; gap: 8px;
          background: #f1f5f9; padding: 12px; border-radius: 8px;
        }
        .wallet-address-display code {
          flex: 1; font-size: 11px; color: var(--text-main);
          word-break: break-all; font-family: 'Courier New', monospace;
        }
        .copy-btn {
          background: var(--azure); border: none; padding: 6px 10px;
          border-radius: 6px; cursor: pointer; font-size: 14px;
          transition: all 0.2s;
        }
        .copy-btn:hover { transform: scale(1.1); }
        .network-badge {
          background: #ecfdf5; color: #059669; padding: 10px 14px;
          border-radius: 8px; font-size: 13px; font-weight: 600;
          display: inline-flex; align-items: center; gap: 8px;
        }
        .balance-display {
          font-size: 24px; font-weight: 800; color: var(--azure);
        }
        .wallet-actions {
          margin-top: 8px; display: flex; flex-direction: column; gap: 12px;
        }
        .btn-secondary:hover { background: #e2e8f0; }

        /* Notifications */
        .notification {
          position: absolute;
          top: 70px;
          left: 16px;
          right: 16px;
          padding: 12px 16px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 10px;
          z-index: 2000;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
          animation: slideDown 0.3s ease-out;
        }
        @keyframes slideDown {
          from { transform: translateY(-20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .notification-success { background: #ecfdf5; color: #059669; border-left: 4px solid #10b981; }
        .notification-error { background: #fef2f2; color: #dc2626; border-left: 4px solid #ef4444; }
        .notification-info { background: #eff6ff; color: #2563eb; border-left: 4px solid #3b82f6; }
        .btn { transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); }
        .btn:active { transform: scale(0.95); }
        .badge-security { background: #fee2e2; color: #991b1b; }
        .record-card:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.05); }

        /* Bridging Styles */
        .bridge-info-grid {
          margin: 12px 0;
        }
        .bridge-card {
          background: #f8fafc;
          transition: all 0.2s ease;
        }
        .bridge-card:hover {
          border-color: var(--azure) !important;
          background: #f1f5f9;
        }
        .bridge-status-banner {
          border-radius: 6px;
          text-align: center;
          font-weight: 600;
        }
        .bridge-status-banner.bridging { background: #eff6ff; color: #1d4ed8; }
        .bridge-status-banner.success { background: #f0fdf4; color: #166534; }
        .bridge-status-banner.error { background: #fef2f2; color: #991b1b; }

        /* Notification */
        .notification { transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        .wallet-warning {
          font-size: 11px; color: #f59e0b; background: #fffbeb;
          padding: 10px; border-radius: 6px; line-height: 1.5;
          border-left: 3px solid #f59e0b;
        }

        /* Buttons */
        .btn { border: none; cursor: pointer; font-family: inherit; font-weight: 700; transition: all 0.2s; border-radius: 8px; }
        .btn-primary { background: var(--azure); color: white; }
        .btn-lg { width: 100%; padding: 14px; font-size: 15px; }
        .btn:disabled { opacity: 0.5; }

        .p-loading {
          flex: 1; display: flex; align-items: center; justify-content: center;
          background: var(--bg);
        }
        .loading-inner {
          display: flex; flex-direction: column; align-items: center; gap: 14px;
        }
        .gear-spin {
          animation: gear-rotate 1.8s linear infinite;
          filter: drop-shadow(0 4px 16px rgba(59,130,246,0.35));
        }
        @keyframes gear-rotate {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        .loading-text {
          font-size: 15px; font-weight: 700; color: var(--text-main);
          letter-spacing: -0.3px;
        }
        .loading-sub {
          font-size: 11px; color: var(--text-muted); font-weight: 500;
          letter-spacing: 0.2px;
        }
        .empty-state { padding: 40px; text-align: center; color: var(--text-muted); font-size: 13px; }

        /* Import Wallet Modal */
        .import-section { margin-bottom: 20px; }
        .wallet-input {
          width: 100%; padding: 12px; border: 1px solid var(--border);
          border-radius: 8px; font-size: 13px; font-family: monospace;
          margin-bottom: 12px;
        }
        .wallet-input:focus { outline: none; border-color: var(--azure); }
        .import-actions {
          display: flex; gap: 8px; margin-bottom: 12px;
        }
        .import-actions .btn { flex: 1; }
        .import-message {
          padding: 10px; border-radius: 6px; font-size: 12px;
          line-height: 1.5;
        }
        .import-message.error {
          background: #fef2f2; color: #b91c1c; border-left: 3px solid #ef4444;
        }
        .import-message.success {
          background: #ecfdf5; color: #059669; border-left: 3px solid #10b981;
        }
        .import-message.info {
          background: #eff6ff; color: #1e40af; border-left: 3px solid #3b82f6;
        }
        .divider {
          text-align: center; margin: 20px 0; position: relative;
        }
        .divider::before {
          content: ''; position: absolute; top: 50%; left: 0; right: 0;
          height: 1px; background: var(--border);
        }
        .divider span {
          background: var(--surface); padding: 0 12px; position: relative;
          font-size: 11px; font-weight: 700; color: var(--text-muted);
        }
        .wallet-list {
          max-height: 200px; overflow-y: auto; border: 1px solid var(--border);
          border-radius: 8px;
        }
        .wallet-list-item {
          padding: 12px; display: flex; justify-content: space-between;
          align-items: center; border-bottom: 1px solid var(--border);
        }
        .wallet-list-item:last-child { border-bottom: none; }
        .wallet-list-info { flex: 1; }
        .wallet-list-address {
          font-family: monospace; font-size: 12px; font-weight: 600;
          color: var(--text-main);
        }
        .wallet-list-blockchain {
          font-size: 10px; color: var(--text-muted); margin-top: 2px;
        }
        .wallet-imported-badge {
          font-size: 11px; color: #059669; font-weight: 600;
          background: #ecfdf5; padding: 4px 8px; border-radius: 4px;
        }
        .loading-wallets, .empty-wallets {
          padding: 20px; text-align: center; color: var(--text-muted);
          font-size: 12px;
        }
        .import-info {
          background: #fffbeb; border: 1px solid #fbbf24;
          border-radius: 8px; padding: 12px; font-size: 11px;
          line-height: 1.6; color: #92400e;
        }
        .import-info p { margin: 4px 0; }
        .import-info strong { font-weight: 700; }
      `})]})};Ee.createRoot(document.getElementById("root")).render(e.jsx(o.StrictMode,{children:e.jsx(Je,{})}));
